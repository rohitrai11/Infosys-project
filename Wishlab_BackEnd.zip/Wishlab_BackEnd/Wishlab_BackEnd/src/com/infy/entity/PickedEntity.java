package com.infy.entity;

import java.time.LocalDate;



import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "WishPicked")
@GenericGenerator(name = "pkgen", strategy = "increment")
public class PickedEntity {
	
	@Id
	@GeneratedValue(generator = "pkgen")
	private Integer wishId;
	private Integer registerId;
	private String message;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	private String wishes;
	
	private Integer quantity;
	private LocalDate dateOfSelection;
	
	private String status;
	public Integer getWishId() {
		return wishId;
	}
	public void setWishId(Integer wishId) {
		this.wishId = wishId;
	}
	public Integer getregisterId() {
		return registerId;
	}
	public void setregisterId(Integer registerId) {
		this.registerId = registerId;
	}
	
	public String getWishes() {
		return wishes;
	}
	public void setWishes(String wishes) {
		this.wishes = wishes;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public LocalDate getDateOfSelection() {
		return dateOfSelection;
	}
	public void setDateOfSelection(LocalDate dateOfSelection) {
		this.dateOfSelection = dateOfSelection;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
