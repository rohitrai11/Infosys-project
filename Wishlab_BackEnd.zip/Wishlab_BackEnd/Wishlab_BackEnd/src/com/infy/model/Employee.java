package com.infy.model;

public class Employee {
	private Integer registerId;
	private String name;
	private String dept;
	private String address;
	private String contactNo;
	private String email;
	private String password;
	private String usertype;
	private String message;
	private String cnfpassword;
	public String getCnfpassword() {
		return cnfpassword;
	}
	public void setCnfpassword(String cnfpassword) {
		this.cnfpassword = cnfpassword;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getUsertype() {
		return usertype;
	}
	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public Integer getregisterId() {
		return registerId;
	}
	public void setregisterId(Integer registerId) {
		this.registerId = registerId;
	}
	public String getName() {
		return name;
	}
	public void setName(String empName) {
		this.name = empName;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String empDept) {
		this.dept = empDept;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	
}
