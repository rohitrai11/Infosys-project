DROP TABLE WishFullfilled;
DROP TABLE WishPicked;
DROP TABLE Wishlist;
DROP TABLE Admins;
DROP table Volunteer;


DROP TABLE Employee;


create table Volunteer(
registerId number PRIMARY KEY,
usertype varchar2(30),
message varchar2(30),
password varchar2(30) not null,
name varchar2(30) not null,
dept varchar2(50),
address varchar2(30),
contactNo varchar2(12),
email varchar2(30) not null
);
insert into Volunteer values(3,'Volunteer',null,'mar','Marcos','Fin','iyeiwhhjewa','6745786745','marcs@gmail.com');
create table Admins(
registerId number PRIMARY KEY,
usertype varchar2(30),
message varchar2(30),
name varchar(30) not null,
dept varchar(50),
password varchar2(30) not null,
address varchar(30),
contactNo varchar2(12),
email varchar(30) not null
);

insert into Admins values(2,'Admin',null,'Raj','CSE','raj','jfjtkukjklnlkhik','9898787867','raj@gmail.com');

create table Employee(
registerId number PRIMARY KEY,
usertype varchar2(30),
message varchar2(30),
password varchar2(30) not null,
name varchar2(30) not null,
dept varchar2(50),
address varchar2(30),
contactNo varchar2(12),
email varchar2(30) not null
);
insert into Employee values(1,'Employee',null,'Lorna','Lorna','CSE','piepwrow','6756455723','lorna@gmail.com');
create table Wishlist(
wishes varchar2(30) PRIMARY KEY,
registerId number constraint adm_ids_fk references Admins(registerId),
quantity number not null,
priority number not null,
status varchar2(30) not null,
message varchar2(50),
reward number not null
);
insert into Wishlist values('Food',2,0,2,'Required',null,4);
insert into Wishlist values('Bags',2,2,2,'Required',null,4);
insert into Wishlist values('Toys',2,5,2,'Required',null,1);
insert into Wishlist values('Towels',2,5,2,'Required',null,1);

create table WishPicked(
wishId number PRIMARY KEY,
registerId number constraint wis_emp_fk references Employee(registerId),
wishes varchar2(10) constraint wis_pic_fk references Wishlist(wishes),
quantity number not null,
dateOfSelection date,
message varchar2(50),
status varchar2(10) not null
); 

insert into WishPicked values(9,1,'Bags',1,TRUNC(SYSDATE)+1,null,'Pending');
insert into WishPicked values(7,1,'Toys',2,TRUNC(SYSDATE)+1,null,'Pending');

create table WishFullfilled(
fid number PRIMARY KEY,
registerId number constraint emp_ful_fk references Employee(registerId), 
wishId number,
wishes varchar2(10) constraint wis_pifu_fk references Wishlist(wishes)
);

insert into WishFullfilled values(1,1,9,'Bags')

select * from Volunteer;
select * from Wishlist;
select * from Employee;
select * from Admins;
select * from WishPicked;
select * from WishFullfilled;
