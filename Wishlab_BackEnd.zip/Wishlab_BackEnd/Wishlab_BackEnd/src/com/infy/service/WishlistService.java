package com.infy.service;

import java.util.List;

import com.infy.entity.AdminEntity;
import com.infy.entity.EmployeeEntity;
import com.infy.entity.FullfilledEntity;
import com.infy.entity.PickedEntity;
import com.infy.entity.VolunteerEntity;
import com.infy.entity.WishesEntity;
import com.infy.model.Admin;
import com.infy.model.Employee;
import com.infy.model.Volunteer;
import com.infy.model.Wishlist;

public interface WishlistService {
	public PickedEntity pickWishes(Wishlist wishes) throws Exception;
	public String addWishes(Wishlist newWish) throws Exception;
	public void updateStatus(Integer wishId) throws Exception;
	public boolean assignVolunteer(Integer vid)throws Exception;
	public Employee volunteerChoice(Employee emp)throws Exception;
	public boolean unpickWish(Integer wishId) throws Exception;
	public AdminEntity newAdmin(Admin admin) throws Exception;
	public EmployeeEntity newEmployee(Employee employee) throws Exception;
	public VolunteerEntity newVolunteer(Volunteer volunteer) throws Exception;
	public AdminEntity adminLogin(String mail,String password) throws Exception;
	public EmployeeEntity empLogin(String mail,String password) throws Exception;
	public VolunteerEntity volLogin(String mail,String password) throws Exception;
	public void changePassword(Admin admin)throws Exception;
	public void empPassword(Employee employee)throws Exception;
	public void volPassword(Volunteer volunteer)throws Exception;
//	public List<AdminEntity> getAdminDetails()throws Exception;
//	public List<EmployeeEntity> getEmpDetails() throws Exception;
//	public List<VolunteerEntity> getVolDetails() throws Exception;
	public List<WishesEntity> getWishlist() throws Exception;
	public List<PickedEntity> getPicked(Integer empId) throws Exception;
	public List<FullfilledEntity> getFulfilled() throws Exception;
	public List<FullfilledEntity> empFilled(Integer empId) throws Exception;
}
