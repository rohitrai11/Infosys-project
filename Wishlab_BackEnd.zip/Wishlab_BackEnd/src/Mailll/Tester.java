package Mailll;

import java.time.LocalDate;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;



import com.infy.model.Admin;
import com.infy.model.Employee;
import com.infy.model.Volunteer;

public class Tester {

	Validator v=new Validator();
	@Rule
	public ExpectedException ee = ExpectedException.none();
	//test name customer
	@Test
	public void isInvalidAdminName() throws Exception {
		ee.expectMessage("Validator.INVALID_Name");
		Admin c=new Admin();
		c.setContactNo("9896564012");
		c.setEmail("abc@gmail.com");
		c.setName("A");
		c.setPassword("123@a");
		v.validAdminName(c);
	}
	@Test
	public void isValidAdminName() throws Exception {
		ee.expectMessage("Validator.Valid_Name");
		Admin c=new Admin();
		c.setContactNo("9896564012");
		c.setEmail("abc@gmail.com");
		c.setName("ABC");
		c.setPassword("123@a");
		v.validAdminName(c);
	}
	
	
	
	// test email
	@Test
	public void isInvalidAdminEmail() throws Exception {
		ee.expectMessage("Validator.Invalid_Email");
		Admin c=new Admin();
		c.setContactNo("9896564012");
		c.setEmail("abc");
		c.setName("ABC");
		c.setPassword("123@a");
		v.validAdminEmail(c);
	}
	@Test
	public void isValidAdminEmail() throws Exception {
		ee.expectMessage("Validator.Valid_Email");
		Admin c=new Admin();
		c.setContactNo("9896564012");
		c.setEmail("abc@gmail.com");
		c.setName("ABC");
		c.setPassword("123@a");
		v.validAdminEmail(c);
	}
	
	// test phone
		@Test
		public void isInvalidAdminPhone() throws Exception {
			ee.expectMessage("Validator.Invalid_Phone");
			Admin c=new Admin();
			c.setContactNo("98916564012");
			c.setEmail("abc");
			c.setName("ABC");
			c.setPassword("123@a");
			v.validAdminPhone(c);
		}
		@Test
		public void isValidAdminPhone() throws Exception {
			ee.expectMessage("Validator.Valid_Phone");
			Admin c=new Admin();
			c.setContactNo("9896564012");
			c.setEmail("abc@gmail.com");
			c.setName("ABC");
			c.setPassword("123@a");
			v.validAdminPhone(c);
		}
	// delivery test name;

		@Test
		public void isInvalidVolunteerName() throws Exception {
			ee.expectMessage("Validator.INVALID_Name");
			Volunteer c=new Volunteer();
			c.setContactNo("9896564012");
			c.setEmail("abc@gmail.com");
			c.setName("A");
			c.setPassword("123@a");
			v.validVolunteerName(c);
		}
		
		//test password
		@Test
		public void isInvalidVolunteer() throws Exception {
			ee.expectMessage("Validator.Invalid_Password");
			Volunteer c=new Volunteer();
			c.setContactNo("9896564012");
			c.setEmail("abc@gmail.com");
			c.setName("ABC");
			c.setPassword("12");
			v.validVolunteerPassword(c);
		}
		@Test
		public void isValidVolunteer() throws Exception {
			ee.expectMessage("Validator.Valid_Password");
			Volunteer c=new Volunteer();
			c.setContactNo("9896564012");
			c.setEmail("abc@gmail.com");
			c.setName("ABC");
			c.setPassword("123@a");
			v.validVolunteerPassword(c);
		}
		
		// test email
		@Test
		public void isInvalidVolunteerEmail() throws Exception {
			ee.expectMessage("Validator.Invalid_Email");
			Volunteer c=new Volunteer();
			c.setContactNo("9896564012");
			c.setEmail("abc");
			c.setName("ABC");
			c.setPassword("123@a");
			v.validVolunteerEmail(c);
		}
		@Test
		public void isValidVolunteerEmail() throws Exception {
			ee.expectMessage("Validator.Valid_Email");
			Volunteer c=new Volunteer();
			c.setContactNo("9896564012");
			c.setEmail("abc@gmail.com");
			c.setName("ABC");
			c.setPassword("123@a");
			v.validVolunteerEmail(c);
		}
		
		// test phone
			@Test
			public void isInvalidVolunteerPhone() throws Exception {
				ee.expectMessage("Validator.Invalid_Phone");
				Volunteer c=new Volunteer();
				c.setContactNo("98963564012");
				c.setEmail("abc@gmail.com");
				c.setName("ABC");
				c.setPassword("123@a");
				v.validVolunteerPhone(c);
			}
			@Test
			public void isValidVolunteerPhone() throws Exception {
				ee.expectMessage("Validator.Valid_Phone");
				Volunteer c=new Volunteer();
				c.setContactNo("9896564012");
				c.setEmail("abc@gmail.com");
				c.setName("ABC");
				c.setPassword("123@a");
				v.validVolunteerPhone(c);
			}
			
//			// test phone
//				@Test
//				public void isInvalidDeliverDate() throws Exception {
//					ee.expectMessage("Validator.Invalid_Date");
//					DeliveryBoy c=new DeliveryBoy();
//					c.setContactNo("9896564012");
//					c.setEmail("abc@gmail.com");
//					c.setName("ABC");
//					c.setPassword("123@a");
//					v.validDeliveryBoyPhone(c);
//				}
//				@Test
//				public void isValidDeliverDate() throws Exception {
//					ee.expectMessage("Validator.Valid_Date");
//					Customer c=new Customer();
//					c.setContactNo("9896564012");
//					c.setCustomerEmail("abc@gmail.com");
//					c.setCustomerName("ABC");
//					c.setPassword("123@a");
//					v.validCustomerPhone(c);
//				}

			//test password
			@Test
			public void isInvalidAdminPass() throws Exception {
				ee.expectMessage("Validator.Invalid_Password");
				Admin a =new Admin();
				a.setPassword("12a");
				v.validAdminPassword(a);
			}
			@Test
			public void isValidAdminPass() throws Exception {
				ee.expectMessage("Validator.Valid_Password");
				Admin a =new Admin();
				a.setPassword("12agj3");
				v.validAdminPassword(a);
			}
			

		
		
}
