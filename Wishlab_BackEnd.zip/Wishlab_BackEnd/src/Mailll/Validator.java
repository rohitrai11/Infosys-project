package Mailll;
import java.time.LocalDate;

import org.apache.logging.log4j.Logger;

import  com.infy.utility.LogConfig;
import com.infy.model.Admin;
import com.infy.model.Employee;
import com.infy.model.Volunteer;

public class Validator {

	
	// For Customer //
	// for name
	public Void validAdminName(Admin admin) throws Exception{
		if (admin.getName().length()==0||admin.getName().length()==1){
			throw new Exception("Validator.INVALID_Name");
		}
		else
			throw new Exception("Validator.Valid_Name");
		
	}
	
	
	//for phone
	
	public Void validAdminPhone(Admin Admin) throws Exception{
		if(Admin.getContactNo().length()<10)
			throw new Exception("Validator.Invalid_Phone");
		else if (Admin.getContactNo().length()==10){
			int f=0;
			for(int i=1;i<10;i++){
				if(Admin.getContactNo().charAt(0)==Admin.getContactNo().charAt(i))
					f++;
			}
			if(f==9){
				throw new Exception("Validator.Invalid_Phone");
			}
			throw new Exception("Validator.Valid_Phone");
	}
		throw new Exception("Validator.Invalid_Phone");
	}
	// for email

	public Boolean validAdminEmail(Admin Admin) throws Exception{
		int f=0;
		for(int i=0;i<Admin.getEmail().length();i++){
			if (Admin.getEmail().charAt(i)=='@')
				f++;
		}
		if (f==1)
			throw new Exception("Validator.Valid_Email");
		throw new Exception("Validator.Invalid_Email");
		
	}	
	// For DeliveryBoy //
	// for name
	public Boolean validVolunteerName(Volunteer delivery) throws Exception{
		if (delivery.getName().length()<2){
			throw new Exception("Validator.INVALID_Name");
		}
		else
			throw new Exception("Validator.Valid_Name");
	}
	
	// for password
	public Boolean validVolunteerPassword(Volunteer delivery) throws Exception{
		if(delivery.getPassword().length()<4)
			throw new Exception("Validator.Invalid_Password");
		else
			throw new Exception("Validator.Valid_Password");	}
	
	//for phone
	
	public Boolean validVolunteerPhone(Volunteer delivery) throws Exception{
		if(delivery.getContactNo().length()<10)
			throw new Exception("Validator.Invalid_Phone");
		else if (delivery.getContactNo().length()==10){
			int f=0;
			for(int i=1;i<10;i++){
				if(delivery.getContactNo().charAt(0)==delivery.getContactNo().charAt(i))
					f++;
			}
			if(f==9){
				throw new Exception("Validator.Invalid_Phone");
			}
			throw new Exception("Validator.Valid_Phone");
	}
		throw new Exception("Validator.Invalid_Phone");
	}
	
	
	// for email

	public Boolean validVolunteerEmail(Volunteer delivery) throws Exception{
		int f=0;
		for(int i=0;i<delivery.getEmail().length();i++){
			if (delivery.getEmail().charAt(i)=='@')
				f++;
		}
		if (f==1)
			throw new Exception("Validator.Valid_Email");
		throw new Exception("Validator.Invalid_Email");
	}
	

	// for Admin //
	public Void validAdminPassword(Admin admin) throws Exception{
		if(admin.getPassword().length()<4)
			throw new Exception("Validator.Invalid_Password");
		else
			throw new Exception("Validator.Valid_Password");	}

}
