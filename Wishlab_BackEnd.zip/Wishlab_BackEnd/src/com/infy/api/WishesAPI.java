package com.infy.api;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.entity.AdminEntity;
import com.infy.entity.AssignedEntity;
import com.infy.entity.CreditEntity;
import com.infy.entity.EmployeeEntity;
import com.infy.entity.FullfilledEntity;
import com.infy.entity.MappingEntity;
import com.infy.entity.PickedEntity;
import com.infy.entity.RequestEntity;
import com.infy.entity.VolunteerEntity;
import com.infy.entity.WishesEntity;
import com.infy.model.Admin;
import com.infy.model.Assigned;
import com.infy.model.Employee;
import com.infy.model.Mapping;
import com.infy.model.Request;
import com.infy.model.Volunteer;
import com.infy.model.Wishlist;
import com.infy.service.WishlistService;
import com.infy.service.WishlistServiceImpl;
import com.infy.utility.ContextFactory;

@RestController
@Controller("ManageUserRoles")
@CrossOrigin
@RequestMapping(value = "wishesAPI")
public class WishesAPI {
	private WishlistService service;

	@RequestMapping(method = RequestMethod.POST, value = "add")
	public ResponseEntity<Wishlist> addWish(@RequestBody Wishlist newWish) {

		Environment environment = ContextFactory.getContext().getEnvironment();
		ResponseEntity<Wishlist> response = null;
		service = (WishlistService) ContextFactory.getContext().getBean(
				WishlistServiceImpl.class);
		try {
			service.addWishes(newWish);
			newWish.setMessage("Wish added successfully");
			response = new ResponseEntity<Wishlist>(newWish, HttpStatus.OK);
		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage());
			Wishlist w = new Wishlist();
			w.setMessage(message);
			response = new ResponseEntity<Wishlist>(w, HttpStatus.BAD_REQUEST);
		}

		return response;
	}

	@RequestMapping(method = RequestMethod.POST, value = "pick")
	public ResponseEntity<Wishlist> pickWishes(@RequestBody Wishlist wishess) {
		Environment environment = ContextFactory.getContext().getEnvironment();
		ResponseEntity<Wishlist> response = null;
		service = (WishlistService) ContextFactory.getContext().getBean(
				WishlistServiceImpl.class);
		try {

			service.pickWishes(wishess);
			wishess.setMessage("Wish successfully picked");
			response = new ResponseEntity<Wishlist>(wishess, HttpStatus.OK);
		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage());
			Wishlist w = new Wishlist();
			w.setMessage(message);
			response = new ResponseEntity<Wishlist>(w, HttpStatus.BAD_REQUEST);
		}
		return response;
	}

	@RequestMapping(method = RequestMethod.POST, value = "update")
	public ResponseEntity<Mapping> updateStatus(@RequestBody Mapping map) {
		Environment environment = ContextFactory.getContext().getEnvironment();
		ResponseEntity<Mapping> response = null;
		
		service = (WishlistService) ContextFactory.getContext().getBean(
				WishlistServiceImpl.class);
		try {
			//System.out.println(wish.getWishId());
			service.updateStatus(map);
			Mapping m=new Mapping();
			m.setMsg("Wish updated successfully");
			
			response = new ResponseEntity<Mapping>(m, HttpStatus.OK);
		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage());
			Mapping w1 = new Mapping();
			w1.setMsg(message);
			response = new ResponseEntity<Mapping>(w1, HttpStatus.BAD_REQUEST);
		}
		return response;
	}

	@RequestMapping(method = RequestMethod.POST, value = "vchoice")
	public ResponseEntity<PickedEntity> volunteerChoice(
			@RequestBody Employee emp) {
		Environment environment = ContextFactory.getContext().getEnvironment();
		ResponseEntity<PickedEntity> response = null;
		service = (WishlistService) ContextFactory.getContext().getBean(
				WishlistServiceImpl.class);
		try {
			service.volunteerChoice(emp);
		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage());
			Wishlist w1 = new Wishlist();
			w1.setMessage(message);
			PickedEntity p = new PickedEntity();
			p.setMessage(message);
			// System.out.println(emp.getregisterId());
			p.setStatus("Pending");
			response = new ResponseEntity<PickedEntity>(p, HttpStatus.OK);
		}
		return response;
	}

	@RequestMapping(method = RequestMethod.POST, value = "assign")
	public ResponseEntity<Mapping> assignVolunteer(
			@RequestBody Mapping map) {
		Environment environment = ContextFactory.getContext().getEnvironment();
		ResponseEntity<Mapping> response = null;
		service = (WishlistService) ContextFactory.getContext().getBean(
				WishlistServiceImpl.class);
		try {
			if (service.assignVolunteer(map)) {
				Mapping w = new Mapping();
				w.setMsg("Volunteer assigned successfully");
				response = new ResponseEntity<Mapping>(w, HttpStatus.OK);
			}
		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage());
			Mapping w1 = new Mapping();
			w1.setMsg(message);
			response = new ResponseEntity<Mapping>(w1, HttpStatus.BAD_REQUEST);
		}
		return response;
	}

	@RequestMapping(method = RequestMethod.POST, value = "unpick")
	public ResponseEntity<PickedEntity> unpickWish(
			@RequestBody PickedEntity wish) {
		Environment environment = ContextFactory.getContext().getEnvironment();
		ResponseEntity<PickedEntity> response = null;
		service = (WishlistService) ContextFactory.getContext().getBean(
				WishlistServiceImpl.class);
		try {
			service.unpickWish(wish.getWishId());
			wish.setStatus("Required");
			wish.setMessage("Wish unpicked Successfully");
			response = new ResponseEntity<PickedEntity>(wish, HttpStatus.OK);
		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage());
			wish.setMessage(message);
			response = new ResponseEntity<PickedEntity>(wish,
					HttpStatus.BAD_REQUEST);
		}
		return response;
	}

	@RequestMapping(method = RequestMethod.POST, value = "registerAdmin")
	public ResponseEntity<AdminEntity> registerAdmin(@RequestBody Admin admin) {
		Environment environment = ContextFactory.getContext().getEnvironment();
		ResponseEntity<AdminEntity> response = null;

		service = (WishlistService) ContextFactory.getContext().getBean(
				WishlistServiceImpl.class);
		try {
			AdminEntity adm = service.newAdmin(admin);
			adm.setMessage("Admin successfully registered with id : "
					+ adm.getregisterId());
			response = new ResponseEntity<AdminEntity>(adm, HttpStatus.OK);
		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage());
			AdminEntity adm = new AdminEntity();
			adm.setMessage(message);
			response = new ResponseEntity<AdminEntity>(adm,
					HttpStatus.BAD_REQUEST);
		}
		return response;
	}

	@RequestMapping(method = RequestMethod.POST, value = "registerEmployee")
	public ResponseEntity<EmployeeEntity> registerEmployee(
			@RequestBody Employee employee) {
		Environment environment = ContextFactory.getContext().getEnvironment();
		ResponseEntity<EmployeeEntity> response = null;
		System.out.println(employee.getName() + "  API");
		service = (WishlistService) ContextFactory.getContext().getBean(
				WishlistServiceImpl.class);
		try {
			EmployeeEntity adm = service.newEmployee(employee);
			adm.setMessage("employee successfully registered with id : "
					+ adm.getregisterId());
			response = new ResponseEntity<EmployeeEntity>(adm, HttpStatus.OK);
		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage());
			EmployeeEntity w = new EmployeeEntity();
			w.setMessage(message);
			response = new ResponseEntity<EmployeeEntity>(w,
					HttpStatus.BAD_REQUEST);
		}
		return response;
	}

	@RequestMapping(method = RequestMethod.POST, value = "registerVolunteer")
	public ResponseEntity<VolunteerEntity> registerVolunteer(
			@RequestBody Volunteer volunteer) {
		Environment environment = ContextFactory.getContext().getEnvironment();
		ResponseEntity<VolunteerEntity> response = null;

		service = (WishlistService) ContextFactory.getContext().getBean(
				WishlistServiceImpl.class);
		try {
			VolunteerEntity adm = service.newVolunteer(volunteer);
			adm.setMessage("Successfully registered with id : "
					+ adm.getregisterId());
			response = new ResponseEntity<VolunteerEntity>(adm, HttpStatus.OK);
		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage());
			VolunteerEntity w = new VolunteerEntity();
			w.setMessage(message);
			response = new ResponseEntity<VolunteerEntity>(w,
					HttpStatus.BAD_REQUEST);
		}
		return response;
	}

	@RequestMapping(method = RequestMethod.POST, value = "adminLogin")
	public ResponseEntity<AdminEntity> adminLogin(@RequestBody Admin admin) {
		Environment environment = ContextFactory.getContext().getEnvironment();
		ResponseEntity<AdminEntity> response = null;

		service = (WishlistService) ContextFactory.getContext().getBean(
				WishlistServiceImpl.class);
		try {
			AdminEntity w = service.adminLogin(admin.getEmail(),
					admin.getPassword());

			String msg = "Welcome " + w.getName();
			w.setMessage(msg);
			response = new ResponseEntity<AdminEntity>(w, HttpStatus.OK);
		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage());
			AdminEntity w = new AdminEntity();
			w.setMessage(message);
			response = new ResponseEntity<AdminEntity>(w,
					HttpStatus.BAD_REQUEST);

		}
		return response;
	}

	@RequestMapping(method = RequestMethod.POST, value = "empLogin")
	public ResponseEntity<EmployeeEntity> empLogin(@RequestBody Employee emp) {
		Environment environment = ContextFactory.getContext().getEnvironment();
		ResponseEntity<EmployeeEntity> response = null;

		service = (WishlistService) ContextFactory.getContext().getBean(
				WishlistServiceImpl.class);
		try {
			EmployeeEntity ee = service.empLogin(emp.getEmail(),
					emp.getPassword());
			String msg = "Welcome " + ee.getName();
			ee.setMessage(msg);
			response = new ResponseEntity<EmployeeEntity>(ee, HttpStatus.OK);
		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage());
			EmployeeEntity ee = new EmployeeEntity();
			ee.setMessage(message);
			response = new ResponseEntity<EmployeeEntity>(ee,
					HttpStatus.BAD_REQUEST);

		}
		return response;
	}

	@RequestMapping(method = RequestMethod.POST, value = "volLogin")
	public ResponseEntity<VolunteerEntity> volLogin(@RequestBody Volunteer vol) {
		Environment environment = ContextFactory.getContext().getEnvironment();
		ResponseEntity<VolunteerEntity> response = null;

		service = (WishlistService) ContextFactory.getContext().getBean(
				WishlistServiceImpl.class);
		try {
			VolunteerEntity ve = service.volLogin(vol.getEmail(),
					vol.getPassword());
			String msg = "Welcome " + ve;
			ve.setMessage(msg);
			response = new ResponseEntity<VolunteerEntity>(ve, HttpStatus.OK);
		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage());
			VolunteerEntity ve = new VolunteerEntity();
			ve.setMessage(message);
			response = new ResponseEntity<VolunteerEntity>(ve,
					HttpStatus.BAD_REQUEST);

		}
		return response;
	}

	@RequestMapping(method = RequestMethod.POST, value = "changePassword")
	public ResponseEntity<Wishlist> changePassword(@RequestBody Admin admin) {
		Environment environment = ContextFactory.getContext().getEnvironment();
		ResponseEntity<Wishlist> response = null;
		Wishlist w = new Wishlist();
		service = (WishlistService) ContextFactory.getContext().getBean(
				WishlistServiceImpl.class);
		try {
			// System.out.println(admin.getregisterId());
			service.changePassword(admin);
			String msg = "Password changed successfully";
			w.setMessage(msg);
			response = new ResponseEntity<Wishlist>(w, HttpStatus.OK);
		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage());
			w.setMessage(message);
			response = new ResponseEntity<Wishlist>(w, HttpStatus.BAD_REQUEST);
		}
		return response;
	}

	@RequestMapping(method = RequestMethod.POST, value = "empPassword")
	public ResponseEntity<Wishlist> changePassword(@RequestBody Employee emp) {
		Environment environment = ContextFactory.getContext().getEnvironment();
		ResponseEntity<Wishlist> response = null;
		Wishlist w = new Wishlist();
		service = (WishlistService) ContextFactory.getContext().getBean(
				WishlistServiceImpl.class);
		try {
			// System.out.println(admin.getregisterId());
			service.empPassword(emp);
			String msg = "Password changed successfully";
			w.setMessage(msg);
			response = new ResponseEntity<Wishlist>(w, HttpStatus.OK);
		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage());
			w.setMessage(message);
			response = new ResponseEntity<Wishlist>(w, HttpStatus.BAD_REQUEST);
		}
		return response;
	}

	@RequestMapping(method = RequestMethod.POST, value = "volPassword")
	public ResponseEntity<Wishlist> changePassword(@RequestBody Volunteer vol) {
		Environment environment = ContextFactory.getContext().getEnvironment();
		ResponseEntity<Wishlist> response = null;
		Wishlist w = new Wishlist();
		service = (WishlistService) ContextFactory.getContext().getBean(
				WishlistServiceImpl.class);
		try {
			// System.out.println(admin.getregisterId());
			service.volPassword(vol);
			String msg = "Password changed successfully";
			w.setMessage(msg);
			response = new ResponseEntity<Wishlist>(w, HttpStatus.OK);
		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage());
			w.setMessage(message);
			response = new ResponseEntity<Wishlist>(w, HttpStatus.BAD_REQUEST);
		}
		return response;
	}

	 @RequestMapping(method=RequestMethod.POST, value="getAdmin")
	 public ResponseEntity<AdminEntity> getAdminDetails(@RequestBody Integer admin){
	 Environment environment= ContextFactory.getContext().getEnvironment();
	 ResponseEntity<AdminEntity> response=null;
	 
	 service=(WishlistService)
	 ContextFactory.getContext().getBean(WishlistServiceImpl.class);
	 try{
	 AdminEntity adm=service.getAdminDetails(admin);
	 
	 response=new ResponseEntity<AdminEntity>(adm,HttpStatus.OK);
	 
	 }
	 catch(Exception e){
	 response=new ResponseEntity<AdminEntity>(HttpStatus.BAD_REQUEST);
	 }
	 return response;
	 }
	 @RequestMapping(method=RequestMethod.POST, value="getEmp")
	 public ResponseEntity<EmployeeEntity> getEmpDetails(@RequestBody Integer emp){
	 Environment environment= ContextFactory.getContext().getEnvironment();
	 ResponseEntity<EmployeeEntity> response=null;
	 
	 service=(WishlistService)
	 ContextFactory.getContext().getBean(WishlistServiceImpl.class);
	 try{
	 EmployeeEntity ee=service.getEmpDetails(emp);
	 
	 response=new ResponseEntity<EmployeeEntity>(ee,HttpStatus.OK);
	 
	 }
	 catch(Exception e){
	 response=new ResponseEntity<EmployeeEntity>(HttpStatus.BAD_REQUEST);
	 }
	 return response;
	 }
	 @RequestMapping(method=RequestMethod.POST, value="getVol")
	 public ResponseEntity<VolunteerEntity> getVolDetails(@RequestBody Integer vol){
	 Environment environment= ContextFactory.getContext().getEnvironment();
	 ResponseEntity<VolunteerEntity> response=null;
	 
	 service=(WishlistService)
	 ContextFactory.getContext().getBean(WishlistServiceImpl.class);
	 try{
		 VolunteerEntity ee=service.getVolDetails(vol);
	 
	 response=new ResponseEntity<VolunteerEntity>(ee,HttpStatus.OK);
	 
	 }
	 catch(Exception e){
	 response=new ResponseEntity<VolunteerEntity>(HttpStatus.BAD_REQUEST);
	 }
	 return response;
	 }
	 @RequestMapping(method=RequestMethod.GET, value="getAllPicked")
	 public List<PickedEntity> getDetails(){
	 Environment environment= ContextFactory.getContext().getEnvironment();
	 ResponseEntity<PickedEntity> response=null;
	 List<PickedEntity> list=new ArrayList<PickedEntity>();
	 List<PickedEntity> list1=new ArrayList<PickedEntity>();
	 service=(WishlistService)
	 ContextFactory.getContext().getBean(WishlistServiceImpl.class);
	 try{
	 list.addAll(service.getAllPicked());
	 for(PickedEntity adm:list){
	 response=new ResponseEntity<PickedEntity>(adm,HttpStatus.OK);
	 //System.out.println(response.getBody().getClass());
	 list1.add(response.getBody());
	 }
	 }
	 catch(Exception e){
	 response=new ResponseEntity<PickedEntity>(HttpStatus.BAD_REQUEST);
	 }
	 return list1;
	 }
	@RequestMapping(method = RequestMethod.GET, value = "wishlist")
	public List<WishesEntity> getWishlist() {
		Environment environment = ContextFactory.getContext().getEnvironment();
		ResponseEntity<WishesEntity> response = null;
		List<WishesEntity> list = new ArrayList<WishesEntity>();
		List<WishesEntity> list1 = new ArrayList<WishesEntity>();
		service = (WishlistService) ContextFactory.getContext().getBean(
				WishlistServiceImpl.class);
		try {
			list.addAll(service.getWishlist());
			// System.out.println(list);
			for (WishesEntity adm : list) {
				System.out.println("API     " + adm);
				response = new ResponseEntity<WishesEntity>(adm, HttpStatus.OK);
				System.out.println(response.getBody().getClass());
				list1.add(response.getBody());
			}
		} catch (Exception e) {
			response = new ResponseEntity<WishesEntity>(HttpStatus.BAD_REQUEST);
		}
		return list1;
	}

	@RequestMapping(method = RequestMethod.POST, value = "wishPicked")
	public List<PickedEntity> getPicked(@RequestBody Employee emp) {
		Environment environment = ContextFactory.getContext().getEnvironment();
		ResponseEntity<PickedEntity> response = null;
		List<PickedEntity> list = new ArrayList<PickedEntity>();
		List<PickedEntity> list1 = new ArrayList<PickedEntity>();
		service = (WishlistService) ContextFactory.getContext().getBean(
				WishlistServiceImpl.class);
		try {
			// System.out.println(emp.getregisterId());
			list.addAll(service.getPicked(emp.getregisterId()));
			for (PickedEntity adm : list) {
				response = new ResponseEntity<PickedEntity>(adm, HttpStatus.OK);
				// System.out.println(response.getBody().getClass());
				list1.add(response.getBody());
			}
		} catch (Exception e) {
			response = new ResponseEntity<PickedEntity>(HttpStatus.BAD_REQUEST);
		}
		return list1;
	}

	@RequestMapping(method = RequestMethod.GET, value = "fulfilled")
	public List<FullfilledEntity> getFulfilled() {
		Environment environment = ContextFactory.getContext().getEnvironment();
		ResponseEntity<FullfilledEntity> response = null;
		List<FullfilledEntity> list = new ArrayList<FullfilledEntity>();
		List<FullfilledEntity> list1 = new ArrayList<FullfilledEntity>();
		service = (WishlistService) ContextFactory.getContext().getBean(
				WishlistServiceImpl.class);
		try {
			list.addAll(service.getFulfilled());
			for (FullfilledEntity adm : list) {
				response = new ResponseEntity<FullfilledEntity>(adm,
						HttpStatus.OK);
				// System.out.println(response.getBody().getClass());
				list1.add(response.getBody());
			}
		} catch (Exception e) {
			response = new ResponseEntity<FullfilledEntity>(
					HttpStatus.BAD_REQUEST);
		}
		return list1;
	}

	@RequestMapping(method = RequestMethod.POST, value = "empFilled")
	public List<FullfilledEntity> empFilled(@RequestBody Employee emp) {
		Environment environment = ContextFactory.getContext().getEnvironment();
		ResponseEntity<FullfilledEntity> response = null;
		List<FullfilledEntity> list = new ArrayList<FullfilledEntity>();
		List<FullfilledEntity> list1 = new ArrayList<FullfilledEntity>();
		service = (WishlistService) ContextFactory.getContext().getBean(
				WishlistServiceImpl.class);
		try {
			System.out.println(emp.getregisterId());
			list.addAll(service.empFilled(emp.getregisterId()));
			for (FullfilledEntity adm : list) {
				response = new ResponseEntity<FullfilledEntity>(adm,
						HttpStatus.OK);
				// System.out.println(response.getBody().getClass());
				list1.add(response.getBody());
			}
		} catch (Exception e) {
			response = new ResponseEntity<FullfilledEntity>(
					HttpStatus.BAD_REQUEST);
		}
		return list1;
	}
	@RequestMapping(method = RequestMethod.POST, value = "updateAdmin")
    public ResponseEntity<AdminEntity> updateContact(@RequestBody Admin admin) {
           Environment environment = ContextFactory.getContext().getEnvironment();
           ResponseEntity<AdminEntity> response=null;
           service = (WishlistService) ContextFactory.getContext().getBean(
                        WishlistServiceImpl.class);
           try {
                  AdminEntity adm=service.updateAdminContact(admin);
                  String msg="Updated Successfully";
           	   adm.setMessage(msg);
                  response=new ResponseEntity<AdminEntity>(adm,HttpStatus.OK);
           }
           catch(Exception e){
        	   AdminEntity adm=new AdminEntity();
        	   String msg="Updation failed";
        	   adm.setMessage(msg);
                  response = new ResponseEntity<AdminEntity>(adm,
                               HttpStatus.BAD_REQUEST);
           }
           return response;
    }
	@RequestMapping(method = RequestMethod.POST, value = "updateEmp")
    public ResponseEntity<EmployeeEntity> updateDetails(@RequestBody Employee emp) {
           Environment environment = ContextFactory.getContext().getEnvironment();
           ResponseEntity<EmployeeEntity> response=null;
           service = (WishlistService) ContextFactory.getContext().getBean(
                        WishlistServiceImpl.class);
           try {
        	   EmployeeEntity adm=service.updateEmpContact(emp);
        	   String msg="Updated Successfully";
        	   adm.setMessage(msg);
                  response=new ResponseEntity<EmployeeEntity>(adm,HttpStatus.OK);
           }
           catch(Exception e){
        	   EmployeeEntity adm=new EmployeeEntity();
        	   String msg="Updation failed";
        	   adm.setMessage(msg);
                  response = new ResponseEntity<EmployeeEntity>(adm,
                               HttpStatus.BAD_REQUEST);
           }
           return response;
    }
	@RequestMapping(method = RequestMethod.POST, value = "updateVol")
    public ResponseEntity<VolunteerEntity> updateData(@RequestBody Volunteer vol) {
           Environment environment = ContextFactory.getContext().getEnvironment();
           ResponseEntity<VolunteerEntity> response=null;
           service = (WishlistService) ContextFactory.getContext().getBean(
                        WishlistServiceImpl.class);
           
           try {
        	   VolunteerEntity adm=service.updateVolContact(vol);
        	   String msg="Updated Successfully";
        	   adm.setMessage(msg);
                  response=new ResponseEntity<VolunteerEntity>(adm,HttpStatus.OK);
           }
           catch(Exception e){
        	   VolunteerEntity adm=new VolunteerEntity();
        	   String msg="Updation failed";
        	   adm.setMessage(msg);
                  response = new ResponseEntity<VolunteerEntity>(adm,
                               HttpStatus.BAD_REQUEST);
           }
           return response;
    }
//	@RequestMapping(method = RequestMethod.POST, value = "storeMap")
//	public ResponseEntity<MappingEntity> storeMap(@RequestBody Mapping map){
//		Environment environment = ContextFactory.getContext().getEnvironment();
//        ResponseEntity<MappingEntity> response=null;
//        service = (WishlistService) ContextFactory.getContext().getBean(
//                WishlistServiceImpl.class);
//        MappingEntity m=new MappingEntity();
//   try {
//	   service.storeMap(map);
//	   String msg="Volunteer assigned successfully";
//	   m.setMsg(msg);
//	   response=new ResponseEntity<MappingEntity>(m,HttpStatus.OK);
//   }
//   catch(Exception e){
//	   String msg="Volunteer assigned already. Cannot be assigned again.";
//	   m.setMsg(msg);
//          response = new ResponseEntity<MappingEntity>(m,
//                       HttpStatus.BAD_REQUEST);
//   }
//   return response;
//	}
	@RequestMapping(method=RequestMethod.GET, value="getAllVol")
	 public List<VolunteerEntity> findAll(){
	 Environment environment= ContextFactory.getContext().getEnvironment();
	 ResponseEntity<VolunteerEntity> response=null;
	 List<VolunteerEntity> list=new ArrayList<VolunteerEntity>();
	 List<VolunteerEntity> list1=new ArrayList<VolunteerEntity>();
	 service=(WishlistService)
	 ContextFactory.getContext().getBean(WishlistServiceImpl.class);
	 try{
	 list.addAll(service.findAll());
	 for(VolunteerEntity adm:list){
	 response=new ResponseEntity<VolunteerEntity>(adm,HttpStatus.OK);
	 //System.out.println(response.getBody().getClass());
	 list1.add(response.getBody());
	 }
	 }
	 catch(Exception e){
	 response=new ResponseEntity<VolunteerEntity>(HttpStatus.BAD_REQUEST);
	 }
	 return list1;
	 }
	@RequestMapping(method=RequestMethod.POST, value="showEmp")
	public List<EmployeeEntity> showEmp(@RequestBody Integer vol){
		Environment environment= ContextFactory.getContext().getEnvironment();
		 ResponseEntity<EmployeeEntity> response=null;
		 List<EmployeeEntity> list=new ArrayList<EmployeeEntity>();
		 List<EmployeeEntity> list1=new ArrayList<EmployeeEntity>();
		 service=(WishlistService)
		 ContextFactory.getContext().getBean(WishlistServiceImpl.class);
		 try{
			 System.out.println(vol);
			 list.addAll(service.showEmp(vol));
			 for(EmployeeEntity adm:list){
				 response=new ResponseEntity<EmployeeEntity>(adm,HttpStatus.OK);
				 list1.add(response.getBody());
			 }
		 }catch(Exception e){
			 response=new ResponseEntity<EmployeeEntity>(HttpStatus.BAD_REQUEST);
		 }
		 return list1;
	}
	@RequestMapping(method=RequestMethod.POST, value="showVol")
	public List<VolunteerEntity> showVol(@RequestBody Integer emp){
		Environment environment= ContextFactory.getContext().getEnvironment();
		 ResponseEntity<VolunteerEntity> response=null;
		 List<VolunteerEntity> list=new ArrayList<VolunteerEntity>();
		 List<VolunteerEntity> list1=new ArrayList<VolunteerEntity>();
		 service=(WishlistService)
		 ContextFactory.getContext().getBean(WishlistServiceImpl.class);
		 try{
			 System.out.println(emp);
			 list.addAll(service.showVol(emp));
			 for(VolunteerEntity adm:list){
				 response=new ResponseEntity<VolunteerEntity>(adm,HttpStatus.OK);
				 list1.add(response.getBody());
			 }
		 }catch(Exception e){
			 response=new ResponseEntity<VolunteerEntity>(HttpStatus.BAD_REQUEST);
		 }
		 return list1;
	}
	@RequestMapping(method=RequestMethod.POST, value="acceptReq")
	public List<RequestEntity> acceptReq(@RequestBody Integer vol){
		Environment environment= ContextFactory.getContext().getEnvironment();
		 ResponseEntity<RequestEntity> response=null;
		 List<RequestEntity> list=new ArrayList<RequestEntity>();
		 List<RequestEntity> list1=new ArrayList<RequestEntity>();
		 service=(WishlistService)
		 ContextFactory.getContext().getBean(WishlistServiceImpl.class);
		 try{
			 list.addAll(service.acceptReq(vol));
			 for(RequestEntity adm:list){
				 response=new ResponseEntity<RequestEntity>(adm,HttpStatus.OK);
				 list1.add(response.getBody());
			 }
		 }catch(Exception e){
			 response=new ResponseEntity<RequestEntity>(HttpStatus.BAD_REQUEST);
		 }
		 return list;
	}
	@RequestMapping(method=RequestMethod.POST, value="accepted")
	public ResponseEntity<RequestEntity> accepted(@RequestBody Request emp){
		Environment environment= ContextFactory.getContext().getEnvironment();
		 ResponseEntity<RequestEntity> response=null;
		 service=(WishlistService)
				 ContextFactory.getContext().getBean(WishlistServiceImpl.class);
				 try{
					 RequestEntity req=service.accepted(emp);
					 req.setMsg("Request accepted successfully");
					 response=new ResponseEntity<RequestEntity>(req,HttpStatus.OK);
				 }
				 catch(Exception e){
					 RequestEntity req=new RequestEntity();
					 req.setMsg("Error occured");
					 response=new ResponseEntity<RequestEntity>(req,HttpStatus.BAD_REQUEST);
				 }
				 return response;
	}
	@RequestMapping(method=RequestMethod.POST, value="rejectReq")
	public List<AssignedEntity> rejectReq(@RequestBody Integer vol){
		Environment environment= ContextFactory.getContext().getEnvironment();
		 ResponseEntity<AssignedEntity> response=null;
		 List<AssignedEntity> list=new ArrayList<AssignedEntity>();
		 List<AssignedEntity> list1=new ArrayList<AssignedEntity>();
		 service=(WishlistService)
		 ContextFactory.getContext().getBean(WishlistServiceImpl.class);
		 try{
			 list.addAll(service.rejectReq(vol));
			 for(AssignedEntity adm:list){
				 response=new ResponseEntity<AssignedEntity>(adm,HttpStatus.OK);
				 list1.add(response.getBody());
			 }
		 }catch(Exception e){
			 response=new ResponseEntity<AssignedEntity>(HttpStatus.BAD_REQUEST);
		 }
		 return list;
	}
	@RequestMapping(method=RequestMethod.POST, value="rejected")
	public ResponseEntity<AssignedEntity> rejected(@RequestBody Assigned emp){
		Environment environment= ContextFactory.getContext().getEnvironment();
		 ResponseEntity<AssignedEntity> response=null;
		 service=(WishlistService)
				 ContextFactory.getContext().getBean(WishlistServiceImpl.class);
				 try{
					 AssignedEntity req=service.rejected(emp);
					 
					 response=new ResponseEntity<AssignedEntity>(req,HttpStatus.OK);
				 }
				 catch(Exception e){
					 AssignedEntity req=new AssignedEntity();
					 
					 response=new ResponseEntity<AssignedEntity>(req,HttpStatus.BAD_REQUEST);
				 }
				 return response;
	}
//	@RequestMapping(method=RequestMethod.POST, value="credits")
//	public ResponseEntity<CreditEntity> credits(@RequestBody Integer c){
//		Environment environment= ContextFactory.getContext().getEnvironment();
//		 ResponseEntity<CreditEntity> response=null;
//		 service=(WishlistService)
//				 ContextFactory.getContext().getBean(WishlistServiceImpl.class);
//				 try{
//					 CreditEntity cc=service.credits(c);
//					 response=new ResponseEntity<CreditEntity>(cc,HttpStatus.OK);
//				 }
//				 catch(Exception e){
//					 CreditEntity req=new CreditEntity();
//					 
//					 response=new ResponseEntity<CreditEntity>(req,HttpStatus.BAD_REQUEST);
//				 }
//				 return response;
//	}
	@RequestMapping(method=RequestMethod.POST, value="forget")
	public ResponseEntity<VolunteerEntity> forget(@RequestBody Volunteer vol){
		//String maill=mail.substring(1,mail.length()-1);
		Environment environment= ContextFactory.getContext().getEnvironment();
		 ResponseEntity<VolunteerEntity> response=null;
		 service=(WishlistService)
				 ContextFactory.getContext().getBean(WishlistServiceImpl.class);
				 try{
					 String s=service.forget(vol);
					 VolunteerEntity v=new VolunteerEntity();
					 v.setMessage(s);
					 response=new ResponseEntity<VolunteerEntity>(v,HttpStatus.OK);
				 }catch(Exception e){
					 
					 
					 response=new ResponseEntity<VolunteerEntity>(HttpStatus.BAD_REQUEST);
				 }
				 return response;
}
	@RequestMapping(method=RequestMethod.POST, value="admforget")
	public ResponseEntity<AdminEntity> admforget(@RequestBody Admin adm){
		//String maill=mail.substring(1,mail.length()-1);
		Environment environment= ContextFactory.getContext().getEnvironment();
		 ResponseEntity<AdminEntity> response=null;
		 service=(WishlistService)
				 ContextFactory.getContext().getBean(WishlistServiceImpl.class);
				 try{
					 String s=service.admforget(adm);
					 AdminEntity v=new AdminEntity();
					 v.setMessage(s);
					 response=new ResponseEntity<AdminEntity>(v,HttpStatus.OK);
				 }catch(Exception e){
					 
					 
					 response=new ResponseEntity<AdminEntity>(HttpStatus.BAD_REQUEST);
				 }
				 return response;
}
	@RequestMapping(method=RequestMethod.POST, value="empforget")
	public ResponseEntity<EmployeeEntity> empforget(@RequestBody Employee emp){
		//String maill=mail.substring(1,mail.length()-1);
		Environment environment= ContextFactory.getContext().getEnvironment();
		 ResponseEntity<EmployeeEntity> response=null;
		 service=(WishlistService)
				 ContextFactory.getContext().getBean(WishlistServiceImpl.class);
				 try{
					 String s=service.empforget(emp);
					 EmployeeEntity v=new EmployeeEntity();
					 v.setMessage(s);
					 response=new ResponseEntity<EmployeeEntity>(v,HttpStatus.OK);
				 }catch(Exception e){
					 
					 
					 response=new ResponseEntity<EmployeeEntity>(HttpStatus.BAD_REQUEST);
				 }
				 return response;
}
}