package com.infy.dao;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.management.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import Mailll.Mailer;




import com.infy.entity.AdminEntity;
import com.infy.entity.AssignedEntity;
import com.infy.entity.CreditEntity;
import com.infy.entity.EmployeeEntity;
import com.infy.entity.FullfilledEntity;
import com.infy.entity.MappingEntity;
import com.infy.entity.PickedEntity;
import com.infy.entity.RequestEntity;
import com.infy.entity.VolunteerEntity;
import com.infy.entity.WishesEntity;
import com.infy.model.Admin;
import com.infy.model.Assigned;
import com.infy.model.Employee;
import com.infy.model.Mapping;
import com.infy.model.Request;
import com.infy.model.Volunteer;
import com.infy.model.Wishlist;


@Repository(value="dao")
public class WishlistDAOImpl implements WishlistDAO {

	@Autowired
	SessionFactory sessionFactory;
	
	public PickedEntity pickWishes(Wishlist wishes) throws Exception {
		
		Session session = sessionFactory.getCurrentSession();
		
		PickedEntity picked = null;
		//System.out.println(wishes.getWishes());
		WishesEntity wish = (WishesEntity) session.get(WishesEntity.class, wishes.getWishes());
		
		if(wish!=null && wish.getQuantity()>=wishes.getQuantity()){
			Integer s=wish.getQuantity()-wishes.getQuantity();
			wish.setQuantity(s);
			CriteriaBuilder builder = session.getCriteriaBuilder();
	        CriteriaQuery<PickedEntity> criteriaQuery = builder.createQuery(PickedEntity.class);
	        Root<PickedEntity> root = criteriaQuery.from(PickedEntity.class);
	        criteriaQuery.select(root);
	        List<PickedEntity> list=session.createQuery(criteriaQuery).list();
	  
	        for(PickedEntity p:list){
	        	//System.out.println(p);
	        	if(p.getWishes().equals(wishes.getWishes())){
	        		p.setQuantity(p.getQuantity()+wishes.getQuantity());
	        		p.setregisterId(wishes.getregisterId());
	        		return p;
	        	}
	        }
			picked=new PickedEntity();
			picked.setDateOfSelection(LocalDate.now());
			picked.setregisterId(wishes.getregisterId());
			picked.setQuantity(wishes.getQuantity());
			wishes.setStatus("Pending");
			picked.setStatus(wishes.getStatus());
			picked.setWishes(wishes.getWishes());
			picked.setRewards(wishes.getReward());
			session.persist(picked);
		}
		//System.out.println(picked);
		// persisting the flightsBookingEntity object
		return picked;
	}

	public String addWishes(Wishlist newWish) throws Exception{
		//System.out.println("dao");
		Session session = sessionFactory.getCurrentSession();
		
		//System.out.println(newWish.getWishes());
		WishesEntity wish=session.get(WishesEntity.class,newWish.getWishes());
		//System.out.println(wish);
		if(wish==null){
			wish=new WishesEntity();
		wish.setregisterId(newWish.getregisterId());
		wish.setPriority(newWish.getPriority());
		wish.setQuantity(newWish.getQuantity());
		wish.setReward(newWish.getReward());
		wish.setStatus("Required");
		wish.setWishes(newWish.getWishes());
		session.persist(wish);
		}
		else{
			wish.setQuantity(wish.getQuantity()+newWish.getQuantity());
		}
		return newWish.getWishes();
	}
	
	
	public void updateStatus(Mapping map) throws Exception{
		//System.out.println(wishId);
		Session session = sessionFactory.getCurrentSession();
		System.out.println(map.getEid());
		System.out.println(map.getVid());
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<MappingEntity> criteriaQuery = builder.createQuery(MappingEntity.class);
        Root<MappingEntity> root = criteriaQuery.from(MappingEntity.class);
        criteriaQuery.select(root);
        criteriaQuery.where(builder.equal(root.get("eid"), map.getEid()));
        List<MappingEntity> men=session.createQuery(criteriaQuery).list();
        for(MappingEntity s:men){
        	if(map.getVid()==s.getVid()){
        		String wish=s.getWish();
        		System.out.println(wish);
        		CriteriaBuilder builder1 = session.getCriteriaBuilder();
        		CriteriaQuery<PickedEntity> criteriaQuery1 = builder1.createQuery(PickedEntity.class);
                Root<PickedEntity> root1 = criteriaQuery1.from(PickedEntity.class);
                criteriaQuery1.select(root1);
                criteriaQuery1.where(builder1.equal(root1.get("registerId"), map.getEid()));
                List<PickedEntity> pui=session.createQuery(criteriaQuery1).list();
                for(PickedEntity p:pui){
                	System.out.println(p.getWishes());
                	if(p.getWishes().equals(wish)){
                		p.setStatus("Completed");
                		System.out.println(p.getStatus());
                		System.out.println(p.getRewards());
                		System.out.println(p.getQuantity());
                		//p.setWishes(null);
                		FullfilledEntity full=new FullfilledEntity();
        				full.setWishes(p.getWishes());
        				full.setregisterId(p.getregisterId());
        				full.setWishId(p.getWishId());
        				full.setRewards(0);
//        				full.setRewards(full.getRewards()+(p.getRewards()*p.getQuantity()));
//        				session.persist(full);
        				WishesEntity w=session.get(WishesEntity.class,wish);
        				if(w!=null && w.getQuantity()==0)
        					session.delete(w);
        				full.setRewards(full.getRewards()+(w.getReward()*p.getQuantity()));
        				session.persist(full);
        				session.delete(p);
        					CriteriaBuilder builder11 = session.getCriteriaBuilder();
        					CriteriaQuery<RequestEntity> criteriaQuery11 = builder11.createQuery(RequestEntity.class);
        			        Root<RequestEntity> root11 = criteriaQuery11.from(RequestEntity.class);
        			        criteriaQuery11.select(root11);
        			        criteriaQuery11.where(builder.equal(root11.get("eid"), map.getEid()));
        			        List<RequestEntity> lol=session.createQuery(criteriaQuery11).list();
        			        for(RequestEntity s1:lol){
        			        	if(map.getVid()==s1.getRegisterId()){
        			        		session.delete(s1);
        			        	
                	}}
        			        	CriteriaBuilder builder12 = session.getCriteriaBuilder();
            					CriteriaQuery<MappingEntity> criteriaQuery12 = builder12.createQuery(MappingEntity.class);
            			        Root<MappingEntity> root12 = criteriaQuery12.from(MappingEntity.class);
            			        criteriaQuery12.select(root12);
            			        criteriaQuery12.where(builder.equal(root12.get("eid"), map.getEid()));
            			        List<MappingEntity> lo=session.createQuery(criteriaQuery12).list();
            			        for(MappingEntity s2:lo){
            			        	if(map.getVid()==s2.getVid()){
            			        		session.delete(s2);
            			        	
                    	}
                }
        	}
        }
        	}
        	}
	}
		
	public Employee volunteerChoice(Employee emp)throws Exception{
		return null;
	}
	
	public boolean assignVolunteer(Mapping map)throws Exception{
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<MappingEntity> criteriaQuery = builder.createQuery(MappingEntity.class);
        Root<MappingEntity> root = criteriaQuery.from(MappingEntity.class);
        criteriaQuery.select(root);
        criteriaQuery.where(builder.equal(root.get("wish"), map.getWish()));
        List<MappingEntity> men=session.createQuery(criteriaQuery).list();
		System.out.println(map.getWish());
		System.out.println(map.getEid());
		System.out.println(map.getVid());
        for(MappingEntity m:men){
			
			if(m.getEid()==map.getEid() && m.getVid()==map.getVid()){
				return false;
			}
		}
		MappingEntity ml=new MappingEntity();
		ml.setEid(map.getEid());
		ml.setVid(map.getVid());
		ml.setWish(map.getWish());
		session.persist(ml);
		
		EmployeeEntity ee=session.get(EmployeeEntity.class, map.getEid());
		
		
		return true;
	}
	public boolean unpickWish(Integer wishId) throws Exception{
		Session session = sessionFactory.getCurrentSession();
		PickedEntity wish=session.get(PickedEntity.class,wishId);
		LocalDate select=wish.getDateOfSelection();
		LocalDate today=LocalDate.now();
		if(today.minusDays(5).isEqual(select) || today.minusDays(5).isBefore(select)){
			WishesEntity w=session.get(WishesEntity.class, wish.getWishes());
			if(w!=null){
				w.setQuantity(w.getQuantity()+wish.getQuantity());
				session.delete(wish);
			}
			
			return true;
		}
		return false;
	}
	public AdminEntity newAdmin(Admin admin) throws Exception{
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<AdminEntity> criteriaQuery = builder.createQuery(AdminEntity.class);
        Root<AdminEntity> root = criteriaQuery.from(AdminEntity.class);
        criteriaQuery.select(root);
        criteriaQuery.where(builder.equal(root.get("email"), admin.getEmail()));
       // System.out.println("HI");
        AdminEntity adm=session.createQuery(criteriaQuery).uniqueResult();
       // System.out.println(adm);
		if(adm==null){
			adm=new AdminEntity();
			//adm.setregisterId(admin.getregisterId());
			adm.setUsertype("Admin");
			adm.setAddress(admin.getAddress());
			adm.setContactNo(admin.getContactNo());
			adm.setDept(admin.getDept());
			adm.setEmail(admin.getEmail());
			adm.setName(admin.getName());
			adm.setPassword(admin.getPassword());
			adm.setAnswer(admin.getAnswer());
			adm.setQuestion(admin.getQuestion());
			session.persist(adm);
			return adm;
		}
		else
			return null;
	}
	public EmployeeEntity newEmployee(Employee employee) throws Exception{
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<EmployeeEntity> criteriaQuery = builder.createQuery(EmployeeEntity.class);
        Root<EmployeeEntity> root = criteriaQuery.from(EmployeeEntity.class);
        criteriaQuery.select(root);
        criteriaQuery.where(builder.equal(root.get("email"), employee.getEmail()));
        EmployeeEntity adm=session.createQuery(criteriaQuery).uniqueResult();
		if(adm==null){
			adm=new EmployeeEntity();
			//adm.setregisterId(admin.getregisterId());
			adm.setUsertype("Employee");
			adm.setAddress(employee.getAddress());
			adm.setContactNo(employee.getContactNo());
			adm.setDept(employee.getDept());
			adm.setEmail(employee.getEmail());
			adm.setName(employee.getName());
			adm.setPassword(employee.getPassword());
			adm.setAnswer(employee.getAnswer());
			adm.setQuestion(employee.getQuestion());
			session.save(adm);
			System.out.println(adm.getName());
			return adm;
		}
		else
			return null;
	}
	public VolunteerEntity newVolunteer(Volunteer volunteer) throws Exception{
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<VolunteerEntity> criteriaQuery = builder.createQuery(VolunteerEntity.class);
        Root<VolunteerEntity> root = criteriaQuery.from(VolunteerEntity.class);
        criteriaQuery.select(root);
        criteriaQuery.where(builder.equal(root.get("email"), volunteer.getEmail()));
        VolunteerEntity adm=session.createQuery(criteriaQuery).uniqueResult();
		
		if(adm==null){
			adm=new VolunteerEntity();
			//adm.setregisterId(admin.getregisterId());
			adm.setUsertype("Volunteer");
			adm.setAddress(volunteer.getAddress());
			adm.setContactNo(volunteer.getContactNo());
			adm.setDept(volunteer.getDept());
			adm.setEmail(volunteer.getEmail());
			adm.setName(volunteer.getName());
			adm.setPassword(volunteer.getPassword());
			adm.setAnswer(volunteer.getAnswer());
			adm.setQuestion(volunteer.getQuestion());
			
			session.persist(adm);
			return adm;
		}
		else
			return null;
	}
	public AdminEntity adminLogin(String mail,String password){
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<AdminEntity> criteriaQuery = builder.createQuery(AdminEntity.class);
        Root<AdminEntity> root = criteriaQuery.from(AdminEntity.class);
        criteriaQuery.select(root);
        criteriaQuery.where(builder.equal(root.get("email"), mail));
        AdminEntity adm=session.createQuery(criteriaQuery).uniqueResult();

		if(adm!=null){
			if(adm.getPassword().equals(password))
				return adm;
			else
				return null;
		}
		return null;
	}
	public EmployeeEntity empLogin(String mail,String password){
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<EmployeeEntity> criteriaQuery = builder.createQuery(EmployeeEntity.class);
        Root<EmployeeEntity> root = criteriaQuery.from(EmployeeEntity.class);
        criteriaQuery.select(root);
        criteriaQuery.where(builder.equal(root.get("email"), mail));
        EmployeeEntity adm=session.createQuery(criteriaQuery).uniqueResult();
		if(adm!=null){
			if(adm.getPassword().equals(password))
				return adm;
			else
				return null;
		}
		return null;
	}
	public VolunteerEntity volLogin(String mail,String password){
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<VolunteerEntity> criteriaQuery = builder.createQuery(VolunteerEntity.class);
        Root<VolunteerEntity> root = criteriaQuery.from(VolunteerEntity.class);
        criteriaQuery.select(root);
        criteriaQuery.where(builder.equal(root.get("email"), mail));
        VolunteerEntity adm=session.createQuery(criteriaQuery).uniqueResult();
		if(adm!=null){
			if(adm.getPassword().equals(password))
				return adm;
			else
				return null;
		}
		return null;
	}
	public boolean changePassword(Admin admin){
		Session session = sessionFactory.getCurrentSession();
		//System.out.println(admin.getregisterId());
		AdminEntity adm=session.get(AdminEntity.class,admin.getregisterId());
		if(adm!=null){
			adm.setPassword(admin.getPassword());
			return true;}
		else
			return false;
	}
	public boolean empPassword(Employee employee){
		Session session = sessionFactory.getCurrentSession();
		//System.out.println(admin.getregisterId());
		EmployeeEntity adm=session.get(EmployeeEntity.class,employee.getregisterId());
		if(adm!=null){
			adm.setPassword(employee.getPassword());
			return true;}
		else
			return false;
	}
	public boolean volPassword(Volunteer volunteer){
		Session session = sessionFactory.getCurrentSession();
		//System.out.println(admin.getregisterId());
		VolunteerEntity adm=session.get(VolunteerEntity.class,volunteer.getregisterId());
		if(adm!=null){
			adm.setPassword(volunteer.getPassword());
			return true;}
		else
			return false;
	}
	public AdminEntity getAdminDetails(Integer admin){
		Session session = sessionFactory.getCurrentSession();
		AdminEntity adm=session.get(AdminEntity.class,admin);
        return adm;
	}
	public EmployeeEntity getEmpDetails(Integer emp){
		Session session = sessionFactory.getCurrentSession();
		EmployeeEntity ee=session.get(EmployeeEntity.class, emp);
        return ee;
	}
	public VolunteerEntity getVolDetails(Integer vol){
		Session session = sessionFactory.getCurrentSession();
		VolunteerEntity v=session.get(VolunteerEntity.class, vol);
		
        return v;
	}
	
	public List<WishesEntity> getWishlist(){
		Session session = sessionFactory.getCurrentSession();
		//List<WishesEntity> admin=new ArrayList<WishesEntity>();
		CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<WishesEntity> criteriaQuery = builder.createQuery(WishesEntity.class);
        Root<WishesEntity> root=criteriaQuery.from(WishesEntity.class);
        criteriaQuery.select(root);

        List<WishesEntity> list=session.createQuery(criteriaQuery).getResultList();
       
        return list;
	}
	public List<PickedEntity> getPicked(Integer registerId){
		Session session = sessionFactory.getCurrentSession();
		List<PickedEntity> admin=new ArrayList<PickedEntity>();
		CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<PickedEntity> criteriaQuery = builder.createQuery(PickedEntity.class);
        Root<PickedEntity> root = criteriaQuery.from(PickedEntity.class);
        criteriaQuery.select(root);
        criteriaQuery.where(builder.equal(root.get("registerId"), registerId));
        List<PickedEntity> list=session.createQuery(criteriaQuery).list();
        System.out.println(list);
        for(PickedEntity adm:list){
        	admin.add(adm);
	}
        return admin;
	}
	public List<FullfilledEntity> getFulfilled(){
		Session session = sessionFactory.getCurrentSession();
		List<FullfilledEntity> admin=new ArrayList<FullfilledEntity>();
		CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<FullfilledEntity> criteriaQuery = builder.createQuery(FullfilledEntity.class);
        Root<FullfilledEntity> root = criteriaQuery.from(FullfilledEntity.class);
        criteriaQuery.select(root);
        List<FullfilledEntity> list=session.createQuery(criteriaQuery).list();
        for(FullfilledEntity adm:list){
        	admin.add(adm);
        	System.out.println(adm);
	}
        return admin;
	}
	public List<FullfilledEntity> empFilled(Integer registerId){
        Session session = sessionFactory.getCurrentSession();
        List<FullfilledEntity> admin=new ArrayList<FullfilledEntity>();
        CriteriaBuilder builder = session.getCriteriaBuilder();
  CriteriaQuery<FullfilledEntity> criteriaQuery = builder.createQuery(FullfilledEntity.class);
  Root<FullfilledEntity> root = criteriaQuery.from(FullfilledEntity.class);
  criteriaQuery.select(root);
  criteriaQuery.where(builder.equal(root.get("registerId"), registerId));
  List<FullfilledEntity> list=session.createQuery(criteriaQuery).list();
  if(list.size()>0){
       CriteriaBuilder builder1 = session.getCriteriaBuilder();
      CriteriaQuery<PickedEntity> criteriaQuery1 = builder1.createQuery(PickedEntity.class);
      Root<PickedEntity> root1 = criteriaQuery1.from(PickedEntity.class);
      criteriaQuery1.select(root1);
      criteriaQuery1.where(builder1.equal(root1.get("registerId"), registerId));
      List<PickedEntity> list1=session.createQuery(criteriaQuery1).list();
      for(PickedEntity p:list1){
      for(FullfilledEntity f:list){
              if(p.getWishId()==f.getWishId()){
                     session.delete(p);
              }
      }
      }
  }
  return list;
 }
	public AdminEntity updateAdminContact(Admin admin){
        Session session=sessionFactory.getCurrentSession();
        System.out.println(admin.getregisterId());
        System.out.println(admin.getAddress());
        System.out.println(admin.getContactNo());
        System.out.println(admin.getDept());
        
        System.out.println(admin.getEmail());
        AdminEntity adm=session.get(AdminEntity.class, admin.getregisterId());
        if(adm!=null){
        	
        	 if(!admin.getContactNo().equals(""))
               adm.setContactNo(admin.getContactNo());
        	if(!admin.getDept().equals(""))
        		adm.setDept(admin.getDept());
        	if(!admin.getEmail().equals(""))
        		adm.setEmail(admin.getEmail());
        	if(!admin.getAddress().equals(""))
         		adm.setAddress(admin.getAddress());
        	System.out.println(adm.getDept());
        }
        return adm;
 }
	public EmployeeEntity updateEmpContact(Employee emp){
        Session session=sessionFactory.getCurrentSession();
        EmployeeEntity adm=session.get(EmployeeEntity.class, emp.getregisterId());
        System.out.println(emp.getregisterId());
        System.out.println(emp.getAddress());
        System.out.println(emp.getContactNo());
        System.out.println(emp.getDept());
        
        System.out.println(emp.getEmail());
        if(adm!=null){
        	if(!emp.getContactNo().equals(""))
               adm.setContactNo(emp.getContactNo());
        	if(!emp.getDept().equals(""))
               adm.setDept(emp.getDept());
        	if(!emp.getAddress().equals(""))
               adm.setAddress(emp.getAddress());
        	if(!emp.getEmail().equals(""))
        		adm.setEmail(emp.getEmail());
        }
        return adm;
 }
	public VolunteerEntity updateVolContact(Volunteer vol){
        Session session=sessionFactory.getCurrentSession();
        VolunteerEntity adm=session.get(VolunteerEntity.class, vol.getregisterId());
        if(adm!=null){
        	if(!vol.getContactNo().equals(""))
               adm.setContactNo(vol.getContactNo());
        	 if(!vol.getDept().equals(""))
               adm.setDept(vol.getDept());
        	 if(!vol.getAddress().equals(""))
               adm.setAddress(vol.getAddress());
        	 if(!vol.getEmail().equals(""))
        		adm.setEmail(vol.getEmail());
        }
        return adm;
 }
	public List<PickedEntity> getAllPicked(){
		 Session session = sessionFactory.getCurrentSession();
	        
	        CriteriaBuilder builder = session.getCriteriaBuilder();
	  CriteriaQuery<PickedEntity> criteriaQuery = builder.createQuery(PickedEntity.class);
	  Root<PickedEntity> root = criteriaQuery.from(PickedEntity.class);
	  criteriaQuery.select(root);
	  List<PickedEntity> list=session.createQuery(criteriaQuery).list();
	  return list;
	}
	public boolean storeMap(Mapping map){
		Session session = sessionFactory.getCurrentSession();
		MappingEntity m=new MappingEntity();
		m.setEid(map.getEid());
		m.setVid(map.getVid());
		m.setWish(map.getWish());
		session.persist(m);
		return true;
	}
	public List<VolunteerEntity> findAll(){
		Session session = sessionFactory.getCurrentSession();
        
        CriteriaBuilder builder = session.getCriteriaBuilder();
  CriteriaQuery<VolunteerEntity> criteriaQuery = builder.createQuery(VolunteerEntity.class);
  Root<VolunteerEntity> root = criteriaQuery.from(VolunteerEntity.class);
  criteriaQuery.select(root);
  List<VolunteerEntity> list=session.createQuery(criteriaQuery).list();
  return list;
	}
	public List<EmployeeEntity>showEmp(Integer vol){
		Session session = sessionFactory.getCurrentSession();
        System.out.println(vol);
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<MappingEntity> criteriaQuery = builder.createQuery(MappingEntity.class);
        Root<MappingEntity> root = criteriaQuery.from(MappingEntity.class);
        criteriaQuery.select(root);
        criteriaQuery.where(builder.equal(root.get("vid"), vol));
        List<MappingEntity> list=session.createQuery(criteriaQuery).list();
        List<EmployeeEntity> emp=new ArrayList<EmployeeEntity>();
        System.out.println(list);
        for(MappingEntity m:list){
        	Integer id=m.getEid();
        	EmployeeEntity ee=session.get(EmployeeEntity.class, id);
        	emp.add(ee);
        }
        return emp;
	}
	
	public List<VolunteerEntity>showVol(Integer emp){
		Session session = sessionFactory.getCurrentSession();
       // System.out.println(vol.getregisterId());
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<MappingEntity> criteriaQuery = builder.createQuery(MappingEntity.class);
        Root<MappingEntity> root = criteriaQuery.from(MappingEntity.class);
        criteriaQuery.select(root);
        criteriaQuery.where(builder.equal(root.get("eid"), emp));
        List<MappingEntity> list=session.createQuery(criteriaQuery).list();
        List<VolunteerEntity> vol=new ArrayList<VolunteerEntity>();
        System.out.println(list);
        for(MappingEntity m:list){
        	Integer id=m.getVid();
        	VolunteerEntity ee=session.get(VolunteerEntity.class, id);
        	vol.add(ee);
        }
        return vol;
	}
	public List<RequestEntity> acceptReq(Integer vol){
		Session session = sessionFactory.getCurrentSession();
		
		CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<RequestEntity> criteriaQuery = builder.createQuery(RequestEntity.class);
        Root<RequestEntity> root = criteriaQuery.from(RequestEntity.class);
        criteriaQuery.select(root);
        System.out.println(vol);
        criteriaQuery.where(builder.equal(root.get("registerId"), vol));
        List<RequestEntity> list=session.createQuery(criteriaQuery).list();
        
    
        return list;
	}
	public RequestEntity accepted(Request emp){
		Session session = sessionFactory.getCurrentSession();
		RequestEntity req=new RequestEntity();
		req.setAddress(emp.getAddress());
		req.setContactNo(emp.getContactNo());
		req.setDept(emp.getDept());
		req.setEmail(emp.getEmail());
		req.setName(emp.getName());
		req.setEid(emp.getEid());
		req.setRegisterId(emp.getRegisterId());
		session.persist(req);
//		AssignedEntity ass=session.get(AssignedEntity.class, emp.getAid());
//		if(ass!=null)
//			session.delete(ass);
		return req;
	}
	public List<AssignedEntity> rejectReq(Integer vol){
		Session session = sessionFactory.getCurrentSession();
		
		CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<AssignedEntity> criteriaQuery = builder.createQuery(AssignedEntity.class);
        Root<AssignedEntity> root = criteriaQuery.from(AssignedEntity.class);
        criteriaQuery.select(root);
        criteriaQuery.where(builder.equal(root.get("registerId"), vol));
        List<AssignedEntity> list=session.createQuery(criteriaQuery).list();
        
    
        return list;
	}
	public AssignedEntity rejected(Assigned emp){
		Session session = sessionFactory.getCurrentSession();
		AssignedEntity req=new AssignedEntity();
		req.setAddress(emp.getAddress());
		req.setContactNo(emp.getContactNo());
		req.setDept(emp.getDept());
		req.setEmail(emp.getEmail());
		req.setName(emp.getName());
		req.setRegisterId(emp.getRegisterId());
		session.persist(req);
//		AssignedEntity ass=session.get(AssignedEntity.class, emp.getAid());
//		if(ass!=null)
//			session.delete(ass);
		return req;
	}
	public String forget(Volunteer mail) {
		Session session = sessionFactory.getCurrentSession();
//		System.out.println(mail);
//		CriteriaBuilder builder = session.getCriteriaBuilder();
//        CriteriaQuery<AdminEntity> criteriaQuery = builder.createQuery(AdminEntity.class);
//        Root<AdminEntity> root = criteriaQuery.from(AdminEntity.class);
//        criteriaQuery.select(root);
//        criteriaQuery.where(builder.equal(root.get("email"), mail.getEmail()));
//        List<AdminEntity> adm=session.createQuery(criteriaQuery).getResultList();
//        System.out.println("NEW");
//        if(adm.==null){
//        	System.out.println(adm);
//    		CriteriaBuilder builder1 = session.getCriteriaBuilder();
//            CriteriaQuery<EmployeeEntity> criteriaQuery1 = builder1.createQuery(EmployeeEntity.class);
//            Root<EmployeeEntity> root1 = criteriaQuery1.from(EmployeeEntity.class);
//            criteriaQuery1.select(root1);
//            criteriaQuery1.where(builder1.equal(root1.get("email"), mail.getEmail()));
//            List<EmployeeEntity> emp=session.createQuery(criteriaQuery1).getResultList();
//            if(emp.get(0)==null){
            	CriteriaBuilder builder11 = session.getCriteriaBuilder();
                CriteriaQuery<VolunteerEntity> criteriaQuery11 = builder11.createQuery(VolunteerEntity.class);
                Root<VolunteerEntity> root11 = criteriaQuery11.from(VolunteerEntity.class);
                criteriaQuery11.select(root11);
                criteriaQuery11.where(builder11.equal(root11.get("email"), mail.getEmail()));
                VolunteerEntity vol=session.createQuery(criteriaQuery11).getSingleResult();
                if(vol==null)
                	return "Email does not exist";
                else
                {System.out.println("VOL");
                	if(vol.getQuestion().equals(mail.getQuestion()) && vol.getAnswer().equals(mail.getAnswer())){
                		vol.setPassword(mail.getPassword());
                		return "Password changed successfully";
                	}
                	return "Incorrect question and answer combination";
                }
  
	
//            else
//            {System.out.println("EMP");
//            	if(emp.getQuestion().equals(mail.getQuestion()) && emp.getAnswer().equals(mail.getAnswer())){
//            		emp.setPassword(mail.getPassword());
//            		return "Password changed successfully";
//            	}
//            	return "Incorrect question and answer combination";
//            }
//        }
//        else
//        {	System.out.println("ELSE");
//        	if(adm.getQuestion().equals(mail.getQuestion()) && adm.getAnswer().equals(mail.getAnswer())){
//        		adm.setPassword(mail.getPassword());
//        		return "Password changed successfully";
//        	}
//        	return "Incorrect question and answer combination";
//        }

	}
	public String admforget(Admin mail) {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder11 = session.getCriteriaBuilder();
        CriteriaQuery<AdminEntity> criteriaQuery11 = builder11.createQuery(AdminEntity.class);
        Root<AdminEntity> root11 = criteriaQuery11.from(AdminEntity.class);
        criteriaQuery11.select(root11);
        criteriaQuery11.where(builder11.equal(root11.get("email"), mail.getEmail()));
        AdminEntity vol=session.createQuery(criteriaQuery11).getSingleResult();
        if(vol==null)
        	return "Email does not exist";
        else
        {System.out.println("VOL");
        	if(vol.getQuestion().equals(mail.getQuestion()) && vol.getAnswer().equals(mail.getAnswer())){
        		vol.setPassword(mail.getPassword());
        		return "Password changed successfully";
        	}
        	return "Incorrect question and answer combination";
        }
}
	public String empforget(Employee mail) {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder11 = session.getCriteriaBuilder();
        CriteriaQuery<EmployeeEntity> criteriaQuery11 = builder11.createQuery(EmployeeEntity.class);
        Root<EmployeeEntity> root11 = criteriaQuery11.from(EmployeeEntity.class);
        criteriaQuery11.select(root11);
        criteriaQuery11.where(builder11.equal(root11.get("email"), mail.getEmail()));
        EmployeeEntity vol=session.createQuery(criteriaQuery11).getSingleResult();
        if(vol==null)
        	return "Email does not exist";
        else
        {System.out.println("VOL");
        	if(vol.getQuestion().equals(mail.getQuestion()) && vol.getAnswer().equals(mail.getAnswer())){
        		vol.setPassword(mail.getPassword());
        		return "Password changed successfully";
        	}
        	return "Incorrect question and answer combination";
        }
}
}
