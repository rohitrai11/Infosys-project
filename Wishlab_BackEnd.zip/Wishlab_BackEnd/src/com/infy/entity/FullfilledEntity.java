package com.infy.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "WishFullfilled")
@GenericGenerator(name = "fgen", strategy = "increment")
public class FullfilledEntity {
	@Id
	@GeneratedValue(generator = "fgen")
	private Integer fid;
	private Integer registerId;
	private Integer rewards;
	public Integer getRewards() {
		return rewards;
	}
	public void setRewards(Integer rewards) {
		this.rewards = rewards;
	}
	public Integer getregisterId() {
		return registerId;
	}
	public void setregisterId(Integer registerId) {
		this.registerId = registerId;
	}
	private Integer wishId;
	private String wishes;
	public Integer getFid() {
		return fid;
	}
	public void setFid(Integer fid) {
		this.fid = fid;
	}
	public Integer getWishId() {
		return wishId;
	}
	public void setWishId(Integer wishId) {
		this.wishId = wishId;
	}
	public String getWishes() {
		return wishes;
	}
	public void setWishes(String wishes) {
		this.wishes = wishes;
	}
	
}
