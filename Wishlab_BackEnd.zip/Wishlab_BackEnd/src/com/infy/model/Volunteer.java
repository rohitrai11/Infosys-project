package com.infy.model;

public class Volunteer {
	private Integer registerId;
	private String name;
	private String dept;
	private String email;
	private String password;
	private String usertype;
	private String message;
	private String cnfpassword;
	private String question;
	private String answer;
	
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getCnfpassword() {
		return cnfpassword;
	}
	public void setCnfpassword(String cnfpassword) {
		this.cnfpassword = cnfpassword;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getUsertype() {
		return usertype;
	}
	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	private String address;
	private String contactNo;
	public Integer getregisterId() {
		return registerId;
	}
	public void setregisterId(Integer registerId) {
		this.registerId = registerId;
	}
	public String getName() {
		return name;
	}
	public void setName(String vName) {
		this.name = vName;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String vDept) {
		this.dept = vDept;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String vAddress) {
		this.address = vAddress;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	
}
