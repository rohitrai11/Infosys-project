
DROP TABLE Assigned;
DROP TABLE Request;
DROP TABLE Mapping;
DROP TABLE WishFullfilled;
DROP TABLE WishPicked;
DROP TABLE Wishlist;
DROP TABLE Admins;
DROP table Volunteer;


DROP TABLE Employee;


create table Volunteer(
registerId number PRIMARY KEY,
usertype varchar2(30),
message varchar2(30),
password varchar2(30) not null,
name varchar2(30) not null,
dept varchar2(50),
address varchar2(30),
contactNo varchar2(12),
email varchar2(30) not null,
question varchar2(100),
answer varchar(50)
);
--insert into Volunteer values(1,'Admin',null,'Infy@123','Rohit','CSE','dfchfcjhj','7878787878','rohit16.TRN@infosys.com','Date of Birth','January');
--insert into Volunteer values(4,'Volunteer',null,'mkhk','Carlos','Fin','iyeiwhhjewa','6745786745','carss@gmail.com');
--insert into Volunteer values(3,'Volunteer',null,'mar','Marcos','Fin','iyeiwhhjewa','6745786745','marcs@gmail.com');
create table Admins(
registerId number PRIMARY KEY,
usertype varchar2(30),
message varchar2(30),
name varchar(30) not null,
dept varchar(50),
password varchar2(30) not null,
address varchar(30),
contactNo varchar2(12),
email varchar(30) not null,
question varchar2(100),
answer varchar(50)
);
--insert into Admins values(1,'Admin',null,'Raj','CSE','qwerty123!','jfjtkukjklnlkhik','9898787867','raj@infosys.com','PetName','January');
--insert into Admins values(2,'Admin',null,'Raj','CSE','raj','jfjtkukjklnlkhik','9898787867','raj@gmail.com','Date of Birth','January');

create table Employee(
registerId number PRIMARY KEY,
usertype varchar2(30),
message varchar2(30),
password varchar2(30) not null,
name varchar2(30) not null,
dept varchar2(50),
address varchar2(30),
contactNo varchar2(12),
email varchar2(30) not null,
question varchar2(100),
answer varchar(50)
);
--insert into Employee values(1,'Employee',null,'Lorna','Lorna','CSE','piepwrow','6756455723','lorna@gmail.com','Date of Birth','January');
create table Wishlist(
wishes varchar2(30) PRIMARY KEY,
registerId number constraint adm_ids_fk references Admins(registerId),
quantity number not null,
priority number not null,
status varchar2(30) not null,
message varchar2(50),
reward number not null
);
--insert into Wishlist values('Food',2,0,2,'Required',null,4);
--insert into Wishlist values('Bags',2,2,2,'Required',null,4);
--insert into Wishlist values('Toys',2,5,2,'Required',null,1);
--insert into Wishlist values('Towels',2,5,2,'Required',null,1);

create table WishPicked(
wishId number PRIMARY KEY,
registerId number constraint wis_emp_fk references Employee(registerId),
wishes varchar2(10),
quantity number not null,
dateOfSelection date,
message varchar2(50),
status varchar2(10) not null,
rewards number DEFAULT 0
); 

--insert into WishPicked values(10,1,'Bags',1,TRUNC(SYSDATE)+1,null,'Pending',4);
--insert into WishPicked values(1,1,'Toys',2,TRUNC(SYSDATE)+1,null,'Pending',0);

create table WishFullfilled(
fid number PRIMARY KEY,
registerId number constraint emp_ful_fk references Employee(registerId), 
wishId number,
wishes varchar2(10),
rewards number DEFAULT 0
);

--insert into WishFullfilled values(1,1,9,'Bags',4)

create table Mapping(
mid number PRIMARY KEY,
eid number constraint emp_map_fk references Employee(registerId),
vid number constraint vol_map_fk references Volunteer(registerId),
wish varchar2(10) not null,
msg varchar2(50)
);

--drop table request;
create table Request(
rid number PRIMARY KEY,
registerId number not null,
eid number not null,
name varchar2(30) not null,
dept varchar2(50),
address varchar2(30),
contactNo varchar2(12),
email varchar2(30) not null,
msg varchar2(30)
);

--drop table assigned;
create table Assigned(
aid number PRIMARY KEY,
registerId number not null,
name varchar2(30) not null,
dept varchar2(50),
address varchar2(30),
contactNo varchar2(12),
email varchar2(30) not null

);
--insert into mapping values(1,1,3,'Toys',null);
--insert into mapping values(2,3,3,'Toys',null);
--insert into mapping values(3,1,4,'Toys',null);
--
--insert into assigned values(1,3,'Aman','CSE','skjlhs','9876543221','a@GMAIL.COM')
--insert into assigned values(2,1,'Aman','CSE','skjlhs','9876543221','a@GMAIL.COM');
--insert into assigned values(3,1,'CHAman','CSE','skjlhs','9876548921','a@GIL.COM')
ALTER TABLE Mapping
  ADD CONSTRAINT uq_mapping UNIQUE(eid, vid);

 


  select * from Assigned;
  select * from Request;
select * from Mapping;
select * from Volunteer;
select * from Wishlist;
select * from Employee;
select * from Admins;
select * from WishPicked;
select * from WishFullfilled;
