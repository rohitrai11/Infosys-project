export class PickedWish{
    fulfilledId: number;
    wishId: number;
    wishes: String;
    registerId:number;
    quantity:number;
    dateOfSelection:string;
    message:string;
    status:string;
    rewards:number;
}