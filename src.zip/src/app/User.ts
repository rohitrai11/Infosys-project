export class User{
    registerId:number;
    name:string;
    dept:string;
    address:string;
    contactNo:string;
    email:string;
    message:string;

}