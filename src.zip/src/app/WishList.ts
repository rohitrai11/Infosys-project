export class WishList{
 wishes: string;
 registerId:number;
 quantity:number;
 priority:number;
 status:string;
 reward:number; 
 message:string; 
}