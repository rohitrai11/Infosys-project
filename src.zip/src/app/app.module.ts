import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { HttpModule } from '@angular/http';
import { RegisterComponent } from './register/register.component';
import {RegisterService} from './register/register.service';
import { LoginComponent } from './login/login.component'
import { LoginService } from './login/login.service';
import { MainpageComponent } from './mainpage/mainpage.component';
import { MainpageService } from './mainpage/mainpage.service';
import { RouterModule } from '@angular/router';
import { ProfileAdminComponent } from './profile-admin/profile-admin.component';
import { ProfileAdminService } from './profile-admin/profile-admin.service';
import { ProfileEmployeeComponent } from './profile-employee/profile-employee.component';
import { ProfileEmployeeService } from './profile-employee/profile-employee.service';
import { ProfileVolunteerComponent } from './profile-volunteer/profile-volunteer.component';
import { ProfileVolunteerService } from './profile-volunteer/profile-volunteer.service';

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    MainpageComponent,
    ProfileAdminComponent,
    ProfileEmployeeComponent,
    ProfileVolunteerComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpModule,
    RouterModule
  ],
  providers: [RegisterService,LoginService,MainpageService,ProfileAdminService,ProfileEmployeeService,ProfileVolunteerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
