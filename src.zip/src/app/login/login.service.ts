import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import {Headers} from '@angular/http';
import {User} from '../User';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class LoginService {
  private headers = new Headers({'Content-Type': 'application/json'} );
  constructor(private http:Http) { }
  forgetpassword(data):Promise<any> {
    return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/admforget', JSON.stringify(data.value), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json())    
  .catch(this.handleError);
  }
  forgetpasswordemp(data):Promise<any> {
    return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/empforget', JSON.stringify(data.value), {headers: this.headers})    
  .toPromise()
  .then(response=>{response.json();alert("hi")})    
  .catch(this.handleError);
  }
  forgetpasswordvol(data):Promise<any> {
    return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/forget', JSON.stringify(data.value), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json())    
  .catch(this.handleError);
  }
  loginAdmin(data):Promise<any> {
   // alert(data);
    return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/adminLogin', JSON.stringify(data.value), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json())    
  .catch(this.handleError);
  }
  loginEmployee(data):Promise<any> {
    return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/empLogin', JSON.stringify(data.value), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json() )    
  .catch(this.handleError);
  }
  loginVolunteer(data):Promise<any> {
    return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/volLogin', JSON.stringify(data.value), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json() )    
  .catch(this.handleError);
  }

  handleError(error){
    //alert("heyy");
    return Promise.reject(error.json() || error);
  }

}   