import { Component, OnInit, Input } from '@angular/core';
import {User} from '../User';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import {ProfileAdminService} from './profile-admin.service';
import {FulfilledWishes} from '../FulfilledWishes';
import { WishList } from '../WishList';
import {LoginComponent} from '../login/login.component';
import { ActivatedRoute } from '@angular/router';
import {Location} from '@angular/common';
import { PickedWish } from '../../src/app/PickedWish';
@Component({
  selector: 'profile-admin',
  templateUrl: './profile-admin.component.html',
  styleUrls: ['./profile-admin.component.css']
})
export class ProfileAdminComponent implements OnInit {
  public fw: FulfilledWishes[] = [];
  public wl: WishList[]=[];
  public apw: PickedWish[]=[];
  public vol:User[]=[];
  adname:string;
  adaddress:string;
  adcontactNo:string;
  addept:string;
  ademail:string;
  adregisterId:number;
  empname:string;
  empaddress:string;
  empcontactNo:string;
  empdept:string;
  empemail:string;
  empregisterId:number;
  successMessage:string=null;
  errorMessage:string=null;
  avsuccessMessage:string=null;
  averrorMessage:string=null;
  upsuccessMessage:string=null;
  uperrorMessage:string=null;
  addsuccessMessage:string=null;
  adderrorMessage:string=null;
  addWishForm: FormGroup;
  resetPasswordForm: FormGroup;
  showdept:boolean=false;
  showaddress:boolean=false;
  showemail:boolean=false;
  showcontact:boolean=false;
  editForm:FormGroup;
  assignForm:FormGroup;
  assignit:boolean=false;
  

  constructor( private location: Location,private route: ActivatedRoute,private profSer:ProfileAdminService, private formBuilder:FormBuilder) { }
  assign(data){
    
    this.assignit=this.assignit?false:true;
    this.assignForm.setValue({eid:data.registerId,wish:data.wishes,vid:this.assignForm.value.vid});
    this.avsuccessMessage=null;
    this.averrorMessage=null;
    
  }
  edit(data){
    if(data=="dept"){
      this.showaddress=false;
      this.showdept=true;
      this.showcontact=false;
      this.showemail=false;
      this.uperrorMessage=null;
      this.upsuccessMessage=null;
    }
    else if(data=="address"){
      this.showaddress=true;
      this.showdept=false;
      this.showcontact=false;
      this.showemail=false;
      this.uperrorMessage=null;
      this.upsuccessMessage=null;
    }
    else if(data=="email"){
      this.showaddress=false;
      this.showdept=false;
      this.showcontact=false;
      this.showemail=true;
      this.uperrorMessage=null;
      this.upsuccessMessage=null;
    }
    else if(data=="contact"){
      this.showaddress=false;
      this.showdept=false;
      this.showcontact=true;
      this.showemail=false;
      this.uperrorMessage=null;
      this.upsuccessMessage=null;
    }

  }
  
  getVolunteers(){
    this.vol=[];
    this.profSer.getVolunteer().then(response=>{
    
      for(let i of response)
      {
        this.vol.push(i);
      //alert(i);
      }
      }).catch(response=>response);
  }
  getAllPicked(){
    this.apw=[];
    this.profSer.getAllPicked().then(response=>{

      for(let i of response)
      {
        this.apw.push(i);
      
      }
      }).catch(response=>response);
  }
  getWishList(){
    this.wl=[];
    this.profSer.getWishList().then(response=>{
      for(let i of response)
      {
        this.wl.push(i);
      
      }
      }).catch(response=>response);
    }
  
  getFulfilled(){
    this.profSer.getFulfilled().then(response=>{
      for(let i of response)
      {
        this.fw.push(i);
      
      }
      }).catch(response=>response);  
  }
  resetPassword(){
    this.successMessage=null;
    this.errorMessage=null;
    if(this.resetPasswordForm.value.password==this.resetPasswordForm.value.cnfpassword){
    //alert(JSON.stringify(this.resetPasswordForm.value))
    this.profSer.resetPassword(this.resetPasswordForm).then(response=>{this.successMessage=response.message;
    
  }).catch(response=>{this.errorMessage=response.message;});
  }
  else{
    this.errorMessage="Password and Confirm Password do not match";
  }
}
assignVolunteer(){
  this.averrorMessage=null;
  this.avsuccessMessage=null;
  //alert(JSON.stringify(this.assignForm.value))
  this.profSer.assignVolunteer(this.assignForm).then(response=>{this.avsuccessMessage=response.msg;
    //alert(this.avsuccessMessage);
  }).catch(response=>{this.averrorMessage=response.msg;});
  
}
getEmployee(data){
  //alert(JSON.stringify(this.addWishForm.value))
  this.profSer.getEmployee(data).then(response=>{
    this.empname=response.name;
    this.empaddress=response.address;
    this.empcontactNo=response.contactNo;
    this.empdept=response.dept;
    this.empemail=response.email;
    this.empregisterId=response.registerId;
    
}).catch(response=>response);

}
getAdmin(){
  //alert(JSON.stringify(this.addWishForm.value))
  this.profSer.getAdmin(this.adregisterId).then(response=>{
    this.adname=response.name;
    this.adaddress=response.address;
    this.adcontactNo=response.contactNo;
    this.addept=response.dept;
    this.ademail=response.email;
    this.adregisterId=response.registerId;
    
}).catch(response=>response);

}
addWish(){
  //alert(JSON.stringify(this.addWishForm.value))
  this.addsuccessMessage=null;
  this.adderrorMessage=null;
  this.profSer.addWish(this.addWishForm).then(response=>{this.addsuccessMessage=response.message;
    this.getWishList();
}).catch(response=>{this.adderrorMessage=response.message;});

}

update(){
 // alert(JSON.stringify(this.editForm.value))
 this.upsuccessMessage=null;
 this.uperrorMessage=null;
  this.profSer.update(this.editForm).then(response=>{this.upsuccessMessage=response.message;
    this.getAdmin();
}).catch(response=>{this.uperrorMessage=response.message;});

}


  ngOnInit() {
    this.location.replaceState("/admin");
    this.adname=this.route.snapshot.paramMap.get('name'); 
    this.adaddress=this.route.snapshot.paramMap.get('address');
    this.adcontactNo=this.route.snapshot.paramMap.get('contactNo');
    this.addept=this.route.snapshot.paramMap.get('dept');
    this.ademail=this.route.snapshot.paramMap.get('email');
    this.adregisterId=+this.route.snapshot.paramMap.get('registerId');
    this.getAllPicked();  
    this.getWishList();
    this.getFulfilled();
    this.getVolunteers();
    
    this.editForm=this.formBuilder.group(
      {
        dept:[""],
        email:["",[Validators.pattern("^[a-z]{3,}@infosys.com$")]],
        contactNo:["",[Validators.min(1000000000),Validators.max(9999999999)]],
        address:[""],
        registerId:this.adregisterId
      }
    );
    this.assignForm=this.formBuilder.group(
      {
        eid:[""],
        vid:["",[Validators.required]],
        wish:[""]
      }
    );
    this.addWishForm=this.formBuilder.group(
      {
        wishes:["",[Validators.required]],
        quantity:["",[Validators.required,Validators.min(1),Validators.max(50)]],
        priority:["",[Validators.required,Validators.min(1),Validators.max(10)]],
        reward:["",[Validators.required,Validators.min(1),Validators.max(25)]],
        status:["Required"],
        message:[""],
        registerId:[this.adregisterId]

       }
    );
    this.resetPasswordForm=this.formBuilder.group(
      {
        password:["",[Validators.required,Validators.pattern("^(?=.*[A-Za-z])(?=.*[0-9])(?=.*[@$!%*#?&])[A-Za-z0-9@$!%*#?&]{8,}$")]],
        cnfpassword:["",[Validators.required]],
        registerId:[this.adregisterId]
       }
    );
  }

}
