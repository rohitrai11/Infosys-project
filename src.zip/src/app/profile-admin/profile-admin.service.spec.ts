import { TestBed, inject } from '@angular/core/testing';

import { ProfileAdminService } from './profile-admin.service';

describe('Profile-AdminService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ProfileAdminService]
    });
  });

  it('should be created', inject([ProfileAdminService], (service: ProfileAdminService) => {
    expect(service).toBeTruthy();
  }));
});
