import { Component, OnInit, Input } from '@angular/core';
import {User} from '../User';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import {ProfileEmployeeService} from './profile-employee.service';
import {FulfilledWishes} from '../FulfilledWishes';
import { WishList } from '../WishList';
import {LoginComponent} from '../login/login.component';
import { ActivatedRoute } from '@angular/router';
import {Location} from '@angular/common';
import { PickedWish } from '../PickedWish';
@Component({
  selector: 'profile-employee',
  templateUrl: './profile-employee.component.html',
  styleUrls: ['./profile-employee.component.css']
})
export class ProfileEmployeeComponent implements OnInit {
  public fw: FulfilledWishes[] = [];
  public wl: WishList[]=[];
  public pw: PickedWish[]=[];
  public arr: number[]=[];
  public voll:User[]=[];
  pick:PickedWish;
  empname:string;
  empaddress:string;
  empcontactNo:string;
  empdept:string;
  empemail:string;
  empregisterId:number;
  successMessage:string=null;
  errorMessage:string=null;
  unpicksuccessMessage:string=null;
  unpickerrorMessage:string=null;
  upsuccessMessage:string=null;
  uperrorMessage:string=null;
  picksuccessMessage:string=null;
  pickerrorMessage:string=null;
  pickWishForm: FormGroup;
  public us:User;
  getForm: FormGroup;
  showit:boolean=false;
  resetPasswordForm: FormGroup;
  showdept:boolean=false;
  showaddress:boolean=false;
  showemail:boolean=false;
  showcontact:boolean=false;
  editForm:FormGroup;
  assignedVol:number;
  volname:string;
  voladdress:string;
  volcontactNo:string;
  voldept:string;
  volemail:string;
  creditpoint:number=0;

  constructor( private location: Location,private route: ActivatedRoute,private profSer:ProfileEmployeeService, private formBuilder:FormBuilder) { }
  edit(data){
    if(data=="dept"){
      this.showaddress=false;
      this.showdept=true;
      this.showcontact=false;
      this.showemail=false;
      this.uperrorMessage=null;
      this.upsuccessMessage=null;
    }
    else if(data=="address"){
      this.showaddress=true;
      this.showdept=false;
      this.showcontact=false;
      this.showemail=false;
      this.uperrorMessage=null;
      this.upsuccessMessage=null;
    }
    else if(data=="email"){
      this.showaddress=false;
      this.showdept=false;
      this.showcontact=false;
      this.showemail=true;
      this.uperrorMessage=null;
      this.upsuccessMessage=null;
    }
    else if(data=="contact"){
      this.showaddress=false;
      this.showdept=false;
      this.showcontact=true;
      this.showemail=false;
      this.uperrorMessage=null;
      this.upsuccessMessage=null;
    }

  }
  show(data){
    this.showit=this.showit?false:true;
    this.pickerrorMessage=null;
    this.picksuccessMessage=null;
    this.pick=data;
    this.arr=[];
    for (var i = 1; i <= this.pick.quantity; i++) {
      this.arr.push(i);
     this.pickWishForm.setValue({wishes:this.pick.wishes,quantity:1,registerId:this.empregisterId});
  }
  }
  update(){
    //alert(JSON.stringify(this.editForm.value))
    this.profSer.update(this.editForm).then(response=>{this.upsuccessMessage=response.message;
      this.getEmployee();

  }).catch(response=>{this.uperrorMessage=response.message;});
  
  }
  

  getWishList(){
    this.profSer.getWishList().then(response=>{
    this.wl=[];
      for(let i of response)
      { 
        this.wl.push(i);
      
      }
    }).catch(response=>response);
  }
  getEmployee(){
    //alert(JSON.stringify(this.addWishForm.value))
    this.profSer.getEmployee(this.empregisterId).then(response=>{
      this.empname=response.name;
      this.empaddress=response.address;
      this.empcontactNo=response.contactNo;
      this.empdept=response.dept;
      this.empemail=response.email;
      this.empregisterId=response.registerId;
      
  }).catch(response=>response);
  
  }
  
  getFulfilled(){
    this.profSer.getFulfilled(this.getForm).then(response=>{
      
      for(let i of response)
      {
        this.fw.push(i);
        //alert(i.value.creditpoint);
       // alert(i.creditpoint);
       
       // alert(this.creditpoint);
      }
      for (let i of response){
        this.creditpoint=this.creditpoint+i.rewards;
      }
     }).catch(response=>response);  
  }

  getpickedWish(){
    this.profSer.getPickedWish(this.getForm).then(response=>{
     this.pw=[];
      for(let i of response)
      {
        this.pw.push(i);
        //this.creditpoint=i.rewards;
      
      }
      }).catch(response=>response);  
  }
  resetPassword(){
    this.successMessage=null;
    this.errorMessage=null;
    if(this.resetPasswordForm.value.password==this.resetPasswordForm.value.cnfpassword){
    this.profSer.resetPassword(this.resetPasswordForm).then(response=>{this.successMessage=response.message;
  }).catch(response=>{this.errorMessage=response.message;});
  }
  else{
    this.errorMessage="Password and Confirm Password do not match";
  }
}
// getAssignedVol(){
//   //alert(JSON.stringify(this.pickWishForm.value))
//   this.profSer.getAssignedVolunteer(this.empregisterId).then(response=>{this.assignedVol=response.vid;
    
//     this.getVolDet(this.assignedVol);
// }).catch(response=>response);
// }
// getVolDet(data){
//   this.profSer.getVolDet(data).then(response=>{
//     this.voladdress=response.address;
//     this.volcontactNo=response.contactNo;
//     this.voldept=response.dept;
//     this.volemail=response.email;
//     this.volname=response.name;
//   }).catch(response=>response);
// }
pickWish(){
  //alert(JSON.stringify(this.pickWishForm.value))
  
  this.profSer.pickWish(this.pickWishForm).then(response=>{this.picksuccessMessage=response.message;
  this.getWishList();
  this.getpickedWish();
}).catch(response=>{this.pickerrorMessage=response.message;});
}
unpickWish(data){
  this.unpickerrorMessage=null;
  this.unpicksuccessMessage=null;
  this.profSer.unpickWish(data).then(response=>{this.unpicksuccessMessage=response.message;
  this.getWishList();
  this.getpickedWish();
}).catch(response=>{this.unpickerrorMessage=response.message;});
}
showVol(){
  //alert(this.empregisterId);
  this.profSer.showVol(this.empregisterId).then(response=>{  
    //alert(response.name)
    for(let i of response)
    {
      this.voll.push(i);
    
    }
    }).catch(response=>response);
}


  ngOnInit() {  
    this.location.replaceState("/employee");
    this.empname=this.route.snapshot.paramMap.get('name'); 
    this.empaddress=this.route.snapshot.paramMap.get('address');
    this.empcontactNo=this.route.snapshot.paramMap.get('contactNo');
    this.empdept=this.route.snapshot.paramMap.get('dept');
    this.empemail=this.route.snapshot.paramMap.get('email');
    this.empregisterId=+this.route.snapshot.paramMap.get('registerId'); 
    this.showVol();
    this.pickWishForm=this.formBuilder.group(
      {
        wishes:["",Validators.required],
        quantity:["",[Validators.required,Validators.min(1)]],
        registerId:[this.empregisterId]
       }
    );
    this.editForm=this.formBuilder.group(
      {
        dept:[""],
        email:["",[Validators.pattern("^[a-z]{3,}@infosys.com$")]],
        contactNo:["",[Validators.min(1000000000),Validators.max(9999999999)]],
        address:[""],
        registerId:this.empregisterId
      }
    );
    this.resetPasswordForm=this.formBuilder.group(
      {
        password:["",[Validators.required,Validators.pattern("^(?=.*[A-Za-z])(?=.*[0-9])(?=.*[@$!%*#?&])[A-Za-z0-9@$!%*#?&]{8,}$")]],
        cnfpassword:["",[Validators.required]],
        registerId:[this.empregisterId]
       }
    );
    this.getForm=this.formBuilder.group(
      {
        registerId:[this.empregisterId]
       });
       this.getWishList();
       this.getpickedWish();
       this.getFulfilled();
       
  }

}

