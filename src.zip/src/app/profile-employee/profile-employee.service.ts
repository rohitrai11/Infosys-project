import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import {Headers} from '@angular/http';
import {User} from '../User';
import 'rxjs/add/operator/toPromise';
import {FulfilledWishes} from '../FulfilledWishes'
import {WishList} from '../WishList';
import { PickedWish } from '../PickedWish';
@Injectable()
export class ProfileEmployeeService {
  
  private headers = new Headers({'Content-Type': 'application/json'} );
  constructor(private http:Http) { }
 
  getWishList():Promise<WishList[]>{
    return this.http.get('http://localhost:3333/Wishlab_BackEnd/wishesAPI/wishlist').toPromise()
    .then(response=>response.json() )    
    .catch(this.handleError); 
}
  getFulfilled(data):Promise<any>{
    return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/empFilled', JSON.stringify(data.value), {headers: this.headers})    
    .toPromise()
    .then(response=>response.json())    
    .catch(this.handleError);
  }
update(data):Promise<any>{
    return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/updateEmp', JSON.stringify(data.value), {headers: this.headers})    
    .toPromise()
    .then(response=>response.json())    
    .catch(this.handleError);
  }
  showVol(data):Promise<any>{
    return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/showVol', JSON.stringify(data), {headers: this.headers})    
    .toPromise()
    .then(response=>response.json())    
    .catch(this.handleError);
  }
getPickedWish(data):Promise<any>{
  return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/wishPicked', JSON.stringify(data.value), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json())    
  .catch(this.handleError);
}
resetPassword(data):Promise<any>{
    return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/empPassword', JSON.stringify(data.value), {headers: this.headers})    
    .toPromise()
    .then(response=>response.json())    
    .catch(this.handleError);
}
getEmployee(data):Promise<any>{
  return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/getEmp', JSON.stringify(data), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json())    
  .catch(this.handleError);
}
getAssignedVolunteer(data):Promise<any>{
  return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/getAssignedVolunteer', JSON.stringify(data.value), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json())    
  .catch(this.handleError);
}
getVolDet(data):Promise<any>{
  return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/getVol', JSON.stringify(data.value), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json())    
  .catch(this.handleError);
}
pickWish(data):Promise<any>{
  return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/pick', JSON.stringify(data.value), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json())    
  .catch(this.handleError);
}
unpickWish(data):Promise<any>{
  return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/unpick', JSON.stringify(data), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json())    
  .catch(this.handleError);
}
handleError(error){
    return Promise.reject(error.json() || error);
  }

 
}   