import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfileVolunteerComponent } from './profile-volunteer.component';

describe('ProfileVolunteerComponent', () => {
  let component: ProfileVolunteerComponent;
  let fixture: ComponentFixture<ProfileVolunteerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfileVolunteerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfileVolunteerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
