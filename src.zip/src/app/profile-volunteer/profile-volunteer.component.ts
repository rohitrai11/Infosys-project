import { Component, OnInit, Input } from '@angular/core';
import {User} from '../User';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import {ProfileVolunteerService} from './profile-volunteer.service';
import {FulfilledWishes} from '../FulfilledWishes';
import { WishList } from '../WishList';
import {LoginComponent} from '../login/login.component';
import { ActivatedRoute } from '@angular/router';
import {Location} from '@angular/common';
import { PickedWish } from '../PickedWish';
@Component({
  selector: 'profile-volunteer',
  templateUrl: './profile-volunteer.component.html',
  styleUrls: ['./profile-volunteer.component.css']
})
export class ProfileVolunteerComponent implements OnInit {

  public fw: FulfilledWishes[] = [];
  public wl: WishList[]=[];
  public pw: PickedWish[]=[];
  public arr: number[]=[];
  public empp: User[]=[];
  public acceptedempp:User[]=[];
  public rejectedempp:User[]=[];
  pick:PickedWish;
  volname:string;
  voladdress:string;
  volcontactNo:string;
  voldept:string;
  volemail:string;
  volregisterId:number;
  successMessage:string=null;
  errorMessage:string=null;
  rejectsuccessMessage:string=null;
  rejecterrorMessage:string=null;
  upsuccessMessage:string=null;
  uperrorMessage:string=null;
  acceptsuccessMessage:string=null;
  accepterrorMessage:string=null;
  public us:User;
  getForm: FormGroup;
  showit:boolean=false;
  resetPasswordForm: FormGroup;
  showdept:boolean=false;
  showaddress:boolean=false;
  showemail:boolean=false;
  showcontact:boolean=false;
  editForm:FormGroup;
  assignedemp:number;
  empname:string;
  empaddress:string;
  empcontactNo:string;
  empdept:string;
  empemail:string;
  showAcc:Boolean=false;
  showRej:Boolean=false;
  statusUpdateForm: FormGroup;
  statusupdateerrormessage:string=null;
  statusupdatesuccessmessage:string=null;
  form1:FormGroup;
  constructor( private location: Location,private route: ActivatedRoute,private profSer:ProfileVolunteerService, private formBuilder:FormBuilder) { }
  accept(data){

   this.form1.setValue({registerId:this.volregisterId,eid:data.registerId,name:data.name,dept:data.dept,address:data.address,contactNo:data.contactNo,email:data.email});
    this.profSer.accept(this.form1.value).then(response=>{
      this.acceptedEmp();
      //this.showEmp();
    }).catch(response=>response);
    this.empp=this.empp.filter(item => item !== data);
   // this.acceptedempp.push(data);
    
  }
  reject(data){
    data.registerId=this.volregisterId;
    this.profSer.reject(data).then(response=>{
      this.rejectedEmp();
      //this.showEmp();
    }).catch(response=>response);
    this.empp=this.empp.filter(item => item !== data);
   // this.acceptedempp.push(data);
  }
  edit(data){
    if(data=="dept"){
      this.showaddress=false;
      this.showdept=true;
      this.showcontact=false;
      this.showemail=false;
      this.uperrorMessage=null;
      this.upsuccessMessage=null;
    }
    else if(data=="address"){
      this.showaddress=true;
      this.showdept=false;
      this.showcontact=false;
      this.showemail=false;
      this.uperrorMessage=null;
      this.upsuccessMessage=null;
    }
    else if(data=="email"){
      this.showaddress=false;
      this.showdept=false;
      this.showcontact=false;
      this.showemail=true;
      this.uperrorMessage=null;
      this.upsuccessMessage=null;
    }
    else if(data=="contact"){
      this.showaddress=false;
      this.showdept=false;
      this.showcontact=true;
      this.showemail=false;
      this.uperrorMessage=null;
      this.upsuccessMessage=null;
    }

  }
  update(){
    //alert(JSON.stringify(this.editForm.value))
    this.uperrorMessage=null;
    this.upsuccessMessage=null;
    this.profSer.update(this.editForm).then(response=>{this.upsuccessMessage=response.message;
      this.getVolunteer();

  }).catch(response=>{this.uperrorMessage=response.message;});
  
  }
  getVolunteer(){
    //alert(JSON.stringify(this.addWishForm.value))
    this.profSer.getVolunteer(this.volregisterId).then(response=>{
      this.volname=response.name;
      this.voladdress=response.address;
      this.volcontactNo=response.contactNo;
      this.voldept=response.dept;
      this.volemail=response.email;
      this.volregisterId=response.registerId;
      
  }).catch(response=>response);
  
  }
  acceptedEmp(){
    this.profSer.acceptedEmp(this.volregisterId).then(response=>{ 
      this.acceptedempp=[]; 
      //alert(response.name)
        for(let i of response)
      {
        
        this.acceptedempp.push(i);
      
      }
      }).catch(response=>response);
  }
  rejectedEmp(){
    this.profSer.rejectedEmp(this.volregisterId).then(response=>{ 
      this.rejectedempp=[]; 
      //alert(response.name)
        for(let i of response)
      {
        
        this.rejectedempp.push(i);
      
      }
      }).catch(response=>response);
  }
  

  showEmp(){
    this.profSer.showEmp(this.volregisterId).then(response=>{  
      //alert(response.name)
      this.empp=[];
      var flag=0;
        for(let i of response)
      {
       // alert(i.name);
       flag=0;
       for (let k of this.rejectedempp)
       {
       if(k.email.match(i.email))
       {  
        flag=1;
        break;
       }
      }
       for (let j of this.acceptedempp)
       {
       if(j.email.match(i.email))
       {  
        flag=1;
        break;
       }
      }
      if (flag==0){
       this.empp.push(i); 
      }
      }
      }).catch(response=>response);
  }

  
  resetPassword(){
    if(this.resetPasswordForm.value.password==this.resetPasswordForm.value.cnfpassword){
    this.profSer.resetPassword(this.resetPasswordForm).then(response=>{this.successMessage=response.message;
  }).catch(response=>{this.errorMessage=response.message;});
  }
  else{
    this.errorMessage="Password and Confirm Password do not match";
  }
}
// getAssignedEmp(){
//   //alert(JSON.stringify(this.pickWishForm.value))
//   this.profSer.getAssignedEmployee(this.volregisterId).then(response=>{this.assignedemp=response.eid;
    
//     this.getEmpDet(this.assignedemp);
// }).catch(response=>response);
// }
// getEmpDet(data){
//   this.profSer.getEmpDet(data).then(response=>{
//     this.voladdress=response.address;
//     this.volcontactNo=response.contactNo;
//     this.voldept=response.dept;
//     this.volemail=response.email;
//     this.volname=response.name;
//   }).catch(response=>response);
// }
statusUpdate(data){
  this.statusUpdateForm.setValue({eid:data.eid,vid:this.volregisterId});
  this.profSer.statusUpdate(this.statusUpdateForm).then(response=>{this.statusupdatesuccessmessage=response.msg;
    this.acceptedempp=this.acceptedempp.filter(item => item !== data);
  }).catch(response=>{this.statusupdateerrormessage=response.msg;});
   
}




  ngOnInit() {  
    this.location.replaceState("/volunteer");
    this.volname=this.route.snapshot.paramMap.get('name'); 
    this.voladdress=this.route.snapshot.paramMap.get('address');
    this.volcontactNo=this.route.snapshot.paramMap.get('contactNo');
    this.voldept=this.route.snapshot.paramMap.get('dept');
    this.volemail=this.route.snapshot.paramMap.get('email');
    this.volregisterId=+this.route.snapshot.paramMap.get('registerId'); 
    this.acceptedEmp();
    this.rejectedEmp();
    this.showEmp();

    this.statusUpdateForm=this.formBuilder.group(
      {
       eid:["",[Validators.required]],
       vid:["",[Validators.required]]
      }
    );
    this.editForm=this.formBuilder.group(
      {
        dept:[""],
        email:["",[Validators.pattern("^[a-z]{3,}@infosys.com$")]],
        contactNo:["",[Validators.min(1000000000),Validators.max(9999999999)]],
        address:[""],
        registerId:this.volregisterId
      }
    );
    this.resetPasswordForm=this.formBuilder.group(
      {
        password:["",[Validators.required,Validators.pattern("^(?=.*[A-Za-z])(?=.*[0-9])(?=.*[@$!%*#?&])[A-Za-z0-9@$!%*#?&]{8,}$")]],
        cnfpassword:["",[Validators.required]],
        registerId:[this.volregisterId]
       }
    );
    this.getForm=this.formBuilder.group(
      {
        registerId:[this.volregisterId]
       });

       
  this.form1=this.formBuilder.group(
    { registerId:[""],
    eid:[""],
    name:[""],
    dept:[""],
    address:[""],
    contactNo:[""],
    email:[""]

    }
  )

}
}

