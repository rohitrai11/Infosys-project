import { TestBed, inject } from '@angular/core/testing';

import { ProfileVolunteerService } from './profile-volunteer.service';

describe('Profile-VolunteerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ProfileVolunteerService]
    });
  });

  it('should be created', inject([ProfileVolunteerService], (service: ProfileVolunteerService) => {
    expect(service).toBeTruthy();
  }));
});
