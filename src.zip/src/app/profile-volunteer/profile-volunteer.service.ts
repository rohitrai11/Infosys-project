import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import {Headers} from '@angular/http';
import {User} from '../User';
import 'rxjs/add/operator/toPromise';
import {FulfilledWishes} from '../FulfilledWishes'
import {WishList} from '../WishList';
import { PickedWish } from '../PickedWish';
@Injectable()
export class ProfileVolunteerService {
  
  private headers = new Headers({'Content-Type': 'application/json'} );
  constructor(private http:Http) { }
 
  getEmpDet(data):Promise<any>{
    return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/getEmpDet', JSON.stringify(data), {headers: this.headers})    
    .toPromise()
    .then(response=>response.json())    
    .catch(this.handleError);
  } 
  getAssignedEmployee(data):Promise<any>{
    return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/getAssignedEmp', JSON.stringify(data), {headers: this.headers})    
    .toPromise()
    .then(response=>response.json())    
    .catch(this.handleError);
  } 
resetPassword(data):Promise<any>{
    return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/volPassword', JSON.stringify(data.value), {headers: this.headers})    
    .toPromise()
    .then(response=>response.json())    
    .catch(this.handleError);
}
accept(data):Promise<any>{
  return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/accepted', JSON.stringify(data), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json())    
  .catch(this.handleError);
}
reject(data):Promise<any>{
  return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/rejected', JSON.stringify(data), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json())    
  .catch(this.handleError);
}
getVolunteer(data):Promise<any>{
  return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/getVol', JSON.stringify(data), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json())    
  .catch(this.handleError);
}
acceptedEmp(data):Promise<any>{
  return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/acceptReq', JSON.stringify(data), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json())    
  .catch(this.handleError);
}
rejectedEmp(data):Promise<any>{
  return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/rejectReq', JSON.stringify(data), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json())    
  .catch(this.handleError);
}
statusUpdate(data):Promise<any>{
  return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/update', JSON.stringify(data.value), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json())    
  .catch(this.handleError);
}
showEmp(data):Promise<any>{
  return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/showEmp', JSON.stringify(data), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json())    
  .catch(this.handleError);
}

update(data):Promise<any>{
  return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/updateVol', JSON.stringify(data.value), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json())    
  .catch(this.handleError);
}
handleError(error){
    return Promise.reject(error.json() || error);
  }

 
}   