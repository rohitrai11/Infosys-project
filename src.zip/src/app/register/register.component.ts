import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import {RegisterService} from './register.service'
import {Location} from '@angular/common';
import { Router } from '@angular/router';
@Component({
  selector: 'register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
    
    successMessage:string=null;
    errorMessage:string=null;
    registerId:any;
    registerForm:FormGroup;
    
    constructor(private router:Router,private formBuilder:FormBuilder,private registerService:RegisterService) { }
  
    ngOnInit() {

     this.registerForm=this.formBuilder.group(
       { 
          registerAs:["",[Validators.required]],
          name:["",[Validators.required,Validators.pattern("^[A-Z][a-z.]+[ a-zA-Z]*$")]],
          dept:["",[Validators.required]],
          address:["",[Validators.required]],
          contactNo:["",[Validators.required,Validators.min(1000000000),Validators.max(9999999999)]],
          email:["",[Validators.required,Validators.pattern("^[a-z]{3,}@infosys.com$")]],
          password:["",[Validators.required,Validators.pattern("^(?=.*[A-Za-z])(?=.*[0-9])(?=.*[@$!%*#?&])[A-Za-z0-9@$!%*#?&]{8,}$")]],
          question:["",[Validators.required]],
          answer:["",[Validators.required]]
        }
     );
    }


    register() {
      this.successMessage=null;
      this.errorMessage=null;
      if(this.registerForm.value.registerAs=="ADMIN")
      {
        this.registerService.registerAdmin(this.registerForm).then(response=>{this.registerId=response.registerId;this.successMessage=response.message;
         }).catch(response=>{this.errorMessage=response.message;});
    }
    else if(this.registerForm.value.registerAs=="EMPLOYEE")
    {
      this.registerService.registerEmployee(this.registerForm).then(response=>{this.registerId=response.registerId;this.successMessage=response.message;
        }).catch(response=>{this.errorMessage=response.message;});
    }
    else if(this.registerForm.value.registerAs=="VOLUNTEER")
    {
      this.registerService.registerVolunteer(this.registerForm).then(response=>{this.registerId=response.registerId;this.successMessage=response.message;
         }).catch(response=>{this.errorMessage=response.message;});
    }
    else{
      this.errorMessage="Please enter valid Credentials";
    }
    
    }
      
  

}
