export class PickedWish{
    fulfilledId: number;
    wishId: number;
    wishes: String;
    empId:number;
    quantity:number;
    dateOfSelection:string;
    message:string;
    status:string;

}