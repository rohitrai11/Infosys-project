export class WishList{
 wishes: string;
 adminId:number;
 quantity:number;
 priority:number;
 status:string;
 reward:number; 
 message:string; 
}