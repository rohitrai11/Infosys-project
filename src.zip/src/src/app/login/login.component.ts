import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import {LoginService} from './login.service';
import {User} from '../User';
import {ProfileAdminService} from '../profile-admin/profile-admin.service';
import {Router} from '@angular/router'; 

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  successMessage:string;
  errorMessage:string;
  loginForm: FormGroup;
  public user: User;


  constructor(private router:Router,private formBuilder:FormBuilder,private loginService:LoginService, private profAdminService:ProfileAdminService) { }

  ngOnInit() {


   this.loginForm=this.formBuilder.group(
     {
        loginAs:["",[Validators.required]],
        email:["",[Validators.required]],
        password:["",[Validators.required]]
      }
   );
  }
  login() {
    alert(JSON.stringify(this.loginForm.value))
    if(this.loginForm.value.loginAs=="ADMIN"){
    this.loginService.loginAdmin(this.loginForm).then(response=>{this.successMessage=response.message;
    this.user=response;
    alert("hi user "+this.user.name);
    this.router.navigate(['/admin',{name:this.user.name,address:this.user.address,contactNo:this.user.contactNo
    ,dept:this.user.dept,email:this.user.email,registerId:this.user.registerId,skipLocationChange: true }]);
    alert("Hello "+this.successMessage)}).catch(response=>this.errorMessage=response.message);
  }
  else if(this.loginForm.value.loginAs=="EMPLOYEE"){
    
    this.loginService.loginEmployee(this.loginForm).then(response=>{this.successMessage=response.message;
    this.user=response;
    alert("hi user "+this.user.name);
    this.router.navigate(['/employee',{name:this.user.name,address:this.user.address,contactNo:this.user.contactNo
    ,dept:this.user.dept,email:this.user.email,registerId:this.user.registerId,skipLocationChange: true }]);
    alert("Hello "+this.successMessage)}).catch(response=>this.errorMessage=response.message);  
  }
  else if(this.loginForm.value.loginAs=="VOLUNTEER"){
    this.loginService.loginVolunteer(this.loginForm).then(response=>{this.successMessage=response.message;
    this.user=response;
    alert("hi user "+this.user.name);
    this.router.navigate(['/volunteer',{name:this.user.name,address:this.user.address,contactNo:this.user.contactNo
    ,dept:this.user.dept,email:this.user.email,registerId:this.user.registerId,skipLocationChange: true }]);
    alert("Hello "+this.successMessage)}).catch(response=>this.errorMessage=response.message);  
  }
  }
}
