import { Component, OnInit, Input } from '@angular/core';
import {User} from '../User';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import {ProfileAdminService} from './profile-admin.service';
import {FulfilledWishes} from '../FulfilledWishes';
import { WishList } from '../WishList';
import {LoginComponent} from '../login/login.component';
import { ActivatedRoute } from '@angular/router';
import {Location} from '@angular/common';
@Component({
  selector: 'profile-admin',
  templateUrl: './profile-admin.component.html',
  styleUrls: ['./profile-admin.component.css']
})
export class ProfileAdminComponent implements OnInit {
  public fw: FulfilledWishes[] = [];
  public wl: WishList[]=[];
  adname:string;
  adaddress:string;
  adcontactNo:string;
  addept:string;
  ademail:string;
  adregisterId:number;
  successMessage:string;
  errorMessage:string;
  addWishForm: FormGroup;

  constructor( private location: Location,private route: ActivatedRoute,private profSer:ProfileAdminService, private formBuilder:FormBuilder) { }
  getWishList(){
    this.profSer.getWishList().then(response=>{
      for(let i of response)
      {
        this.wl.push(i);
      
      }
      alert("Hello "+response[0].wishes)}).catch(response=>{alert("Hii "+response)}
      );
  }
  
  getFulfilled(){
    this.profSer.getFulfilled().then(response=>{
      for(let i of response)
      {
        this.fw.push(i);
      
      }
      alert("Hello "+response[0].wishes)}).catch(response=>{alert("Hii "+response)});  
  }

addWish(){
  alert(JSON.stringify(this.addWishForm.value))
  this.profSer.addWish(this.addWishForm).then(response=>{this.successMessage=response.message;
  alert("Hello "+this.successMessage);
}).catch(response=>{this.errorMessage=response.message;alert("Hionohnjo "+this.errorMessage);});

}



  ngOnInit() {
    this.location.replaceState("/admin");
    this.adname=this.route.snapshot.paramMap.get('name'); 
    this.adaddress=this.route.snapshot.paramMap.get('address');
    this.adcontactNo=this.route.snapshot.paramMap.get('contactNo');
    this.addept=this.route.snapshot.paramMap.get('dept');
    this.ademail=this.route.snapshot.paramMap.get('email');
    this.adregisterId=+this.route.snapshot.paramMap.get('registerId');  
    this.getWishList();
    this.getFulfilled();

    this.addWishForm=this.formBuilder.group(
      {
        wishes:["",[Validators.required]],
        quantity:["",[Validators.required]],
        priority:["",[Validators.required]],
        reward:["",[Validators.required]],
        status:["Required"],
        message:[""],
        adminId:[this.adregisterId]

       }
    );
  }

}
