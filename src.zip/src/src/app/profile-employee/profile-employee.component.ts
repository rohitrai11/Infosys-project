import { Component, OnInit, Input } from '@angular/core';
import {User} from '../User';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import {ProfileEmployeeService} from './profile-employee.service';
import {FulfilledWishes} from '../FulfilledWishes';
import { WishList } from '../WishList';
import {LoginComponent} from '../login/login.component';
import { ActivatedRoute } from '@angular/router';
import {Location} from '@angular/common';
import { PickedWish } from '../PickedWish';
@Component({
  selector: 'profile-employee',
  templateUrl: './profile-employee.component.html',
  styleUrls: ['./profile-employee.component.css']
})
export class ProfileEmployeeComponent implements OnInit {
  public fw: FulfilledWishes[] = [];
  public wl: WishList[]=[];
  public pw: PickedWish[]=[];
  empname:string;
  empaddress:string;
  empcontactNo:string;
  empdept:string;
  empemail:string;
  empregisterId:number;
  successMessage:string;
  errorMessage:string;
  pickWishForm: FormGroup;

  constructor( private location: Location,private route: ActivatedRoute,private profSer:ProfileEmployeeService, private formBuilder:FormBuilder) { }
  getWishList(){
    this.profSer.getWishList().then(response=>{
      for(let i of response)
      {
        this.wl.push(i);
      
      }
      alert("Hello "+response[0].wishes)}).catch(response=>{alert("Hii "+response)}
      );
  }
  
  getFulfilled(){
    this.profSer.getFulfilled().then(response=>{
      for(let i of response)
      {
        this.fw.push(i);
      
      }
      alert("Hello "+response[0].wishes)}).catch(response=>{alert("Hii "+response)});  
  }

  getpickedWish(){
    this.profSer.getpickedWish().then(response=>{
      for(let i of response)
      {
        this.pw.push(i);
      
      }
      alert("Hello "+response[0].wishes)}).catch(response=>{alert("Hii "+response)});  
  }
pickWish(){
  alert(JSON.stringify(this.pickWishForm.value))
  this.profSer.pickWish(this.pickWishForm).then(response=>{this.successMessage=response.message;
  alert("Hello "+this.successMessage);
}).catch(response=>{this.errorMessage=response.message;alert("Hionohnjo "+this.errorMessage);});
}

unpickWish(data){
  this.getpickedWish();
  alert(JSON.stringify(data.value))
  this.profSer.unpickWish(data).then(response=>{this.successMessage=response.message;
  alert("Hello "+this.successMessage);
}).catch(response=>{this.errorMessage=response.message;alert("Hionohnjo "+this.errorMessage);});
}



  ngOnInit() {
    this.location.replaceState("/employee");
    this.empname=this.route.snapshot.paramMap.get('name'); 
    this.empaddress=this.route.snapshot.paramMap.get('address');
    this.empcontactNo=this.route.snapshot.paramMap.get('contactNo');
    this.empdept=this.route.snapshot.paramMap.get('dept');
    this.empemail=this.route.snapshot.paramMap.get('email');
    this.empregisterId=+this.route.snapshot.paramMap.get('registerId');  
    this.getWishList();
    this.getFulfilled();

    this.pickWishForm=this.formBuilder.group(
      {
        wishes:["",[Validators.required]],
        quantity:["",[Validators.required]]
       }
    );
  }

}

