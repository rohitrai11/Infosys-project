import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import {Headers} from '@angular/http';
import {User} from '../User';
import 'rxjs/add/operator/toPromise';
import {FulfilledWishes} from '../FulfilledWishes'
import {WishList} from '../WishList';
import { PickedWish } from '../PickedWish';
@Injectable()
export class ProfileEmployeeService {
  
  private headers = new Headers({'Content-Type': 'application/json'} );
  constructor(private http:Http) { }
 
  getWishList():Promise<WishList[]>{
    return this.http.get('http://localhost:3333/Wishlab_BackEnd/wishesAPI/wishlist').toPromise()
    .then(response=>response.json() )    
    .catch(this.handleError); 
}
  getFulfilled():Promise<FulfilledWishes[]>{
    return this.http.get('http://localhost:3333/Wishlab_BackEnd/wishesAPI/fulfilled').toPromise()
    .then(response=>response.json() )    
    .catch(this.handleError);
}
getpickedWish():Promise<PickedWish[]>{
  return this.http.get('http://localhost:3333/Wishlab_BackEnd/wishesAPI/picked').toPromise()
  .then(response=>response.json() )    
  .catch(this.handleError);
}
  pickWish(data):Promise<any>{
    return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/pick', JSON.stringify(data.value), {headers: this.headers})    
    .toPromise()
    .then(response=>response.json())    
    .catch(this.handleError);
}
unpickWish(data):Promise<any>{
  return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/unpick', JSON.stringify(data.value), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json())    
  .catch(this.handleError);
}
handleError(error){
    return Promise.reject(error.json() || error);
  }

 
}   