package tester;
import java.time.LocalDate;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import validater.Validater;

import com.infy.model.Admin;
import com.infy.model.Customer;
import com.infy.model.DeliveryBoy;

public class Tester {

	Validater v=new Validater();
	@Rule
	public ExpectedException ee = ExpectedException.none();
	//test name customer
	@Test
	public void isInvalidCustomerName() throws Exception {
		ee.expectMessage("Validator.INVALID_Name");
		Customer c=new Customer();
		c.setContactNo("9896564012");
		c.setCustomerEmail("abc@gmail.com");
		c.setCustomerName("A");
		c.setPassword("123@a");
		v.validCustomerName(c);
	}
	@Test
	public void isValidCustomerName() throws Exception {
		ee.expectMessage("Validator.Valid_Name");
		Customer c=new Customer();
		c.setContactNo("9896564012");
		c.setCustomerEmail("abc@gmail.com");
		c.setCustomerName("ABC");
		c.setPassword("123@a");
		v.validCustomerName(c);
	}
	
	//test password
	@Test
	public void isInvalidCustomerPass() throws Exception {
		ee.expectMessage("Validator.Invalid_Password");
		Customer c=new Customer();
		c.setContactNo("9896564012");
		c.setCustomerEmail("abc@gmail.com");
		c.setCustomerName("ABC");
		c.setPassword("12");
		v.validCustomerPassword(c);
	}
	@Test
	public void isValidCustomerPass() throws Exception {
		ee.expectMessage("Validator.Valid_Password");
		Customer c=new Customer();
		c.setContactNo("9896564012");
		c.setCustomerEmail("abc@gmail.com");
		c.setCustomerName("ABC");
		c.setPassword("123@a");
		v.validCustomerPassword(c);
	}
	
	// test email
	@Test
	public void isInvalidCustomerEmail() throws Exception {
		ee.expectMessage("Validator.Invalid_Email");
		Customer c=new Customer();
		c.setContactNo("9896564012");
		c.setCustomerEmail("abc");
		c.setCustomerName("ABC");
		c.setPassword("123@a");
		v.validCustomerEmail(c);
	}
	@Test
	public void isValidCustomerEmail() throws Exception {
		ee.expectMessage("Validator.Valid_Email");
		Customer c=new Customer();
		c.setContactNo("9896564012");
		c.setCustomerEmail("abc@gmail.com");
		c.setCustomerName("ABC");
		c.setPassword("123@a");
		v.validCustomerEmail(c);
	}
	
	// test phone
		@Test
		public void isInvalidCustomerPhone() throws Exception {
			ee.expectMessage("Validator.Invalid_Phone");
			Customer c=new Customer();
			c.setContactNo("98916564012");
			c.setCustomerEmail("abc");
			c.setCustomerName("ABC");
			c.setPassword("123@a");
			v.validCustomerPhone(c);
		}
		@Test
		public void isValidCustomerPhone() throws Exception {
			ee.expectMessage("Validator.Valid_Phone");
			Customer c=new Customer();
			c.setContactNo("9896564012");
			c.setCustomerEmail("abc@gmail.com");
			c.setCustomerName("ABC");
			c.setPassword("123@a");
			v.validCustomerPhone(c);
		}
	// delivery test name;

		@Test
		public void isInvalidDeliverName() throws Exception {
			ee.expectMessage("Validator.INVALID_Name");
			DeliveryBoy c=new DeliveryBoy();
			c.setContactNo("9896564012");
			c.setEmail("abc@gmail.com");
			c.setName("A");
			c.setPassword("123@a");
			v.validDeliveryBoyName(c);
		}
		@Test
		public void isValidDeliverName() throws Exception {
			ee.expectMessage("Validator.Valid_Name");
			DeliveryBoy c=new DeliveryBoy();
			c.setContactNo("9896564012");
			c.setEmail("abc@gmail.com");
			c.setName("ABC");
			c.setPassword("123@a");
			v.validDeliveryBoyName(c);;
		}
		
		//test password
		@Test
		public void isInvalidDeliverPass() throws Exception {
			ee.expectMessage("Validator.Invalid_Password");
			DeliveryBoy c=new DeliveryBoy();
			c.setContactNo("9896564012");
			c.setEmail("abc@gmail.com");
			c.setName("ABC");
			c.setPassword("12");
			v.validDeliveryBoyPassword(c);
		}
		@Test
		public void isValidDeliverPass() throws Exception {
			ee.expectMessage("Validator.Valid_Password");
			DeliveryBoy c=new DeliveryBoy();
			c.setContactNo("9896564012");
			c.setEmail("abc@gmail.com");
			c.setName("ABC");
			c.setPassword("123@a");
			v.validDeliveryBoyPassword(c);
		}
		
		// test email
		@Test
		public void isInvalidDeliverEmail() throws Exception {
			ee.expectMessage("Validator.Invalid_Email");
			DeliveryBoy c=new DeliveryBoy();
			c.setContactNo("9896564012");
			c.setEmail("abc");
			c.setName("ABC");
			c.setPassword("123@a");
			v.validDeliveryBoyEmail(c);
		}
		@Test
		public void isValidDeliverEmail() throws Exception {
			ee.expectMessage("Validator.Valid_Email");
			DeliveryBoy c=new DeliveryBoy();
			c.setContactNo("9896564012");
			c.setEmail("abc@gmail.com");
			c.setName("ABC");
			c.setPassword("123@a");
			v.validDeliveryBoyEmail(c);
		}
		
		// test phone
			@Test
			public void isInvalidDeliverPhone() throws Exception {
				ee.expectMessage("Validator.Invalid_Phone");
				DeliveryBoy c=new DeliveryBoy();
				c.setContactNo("98963564012");
				c.setEmail("abc@gmail.com");
				c.setName("ABC");
				c.setPassword("123@a");
				v.validDeliveryBoyPhone(c);
			}
			@Test
			public void isValidDeliverPhone() throws Exception {
				ee.expectMessage("Validator.Valid_Phone");
				DeliveryBoy c=new DeliveryBoy();
				c.setContactNo("9896564012");
				c.setEmail("abc@gmail.com");
				c.setName("ABC");
				c.setPassword("123@a");
				v.validDeliveryBoyPhone(c);
			}
			
//			// test phone
//				@Test
//				public void isInvalidDeliverDate() throws Exception {
//					ee.expectMessage("Validator.Invalid_Date");
//					DeliveryBoy c=new DeliveryBoy();
//					c.setContactNo("9896564012");
//					c.setEmail("abc@gmail.com");
//					c.setName("ABC");
//					c.setPassword("123@a");
//					v.validDeliveryBoyPhone(c);
//				}
//				@Test
//				public void isValidDeliverDate() throws Exception {
//					ee.expectMessage("Validator.Valid_Date");
//					Customer c=new Customer();
//					c.setContactNo("9896564012");
//					c.setCustomerEmail("abc@gmail.com");
//					c.setCustomerName("ABC");
//					c.setPassword("123@a");
//					v.validCustomerPhone(c);
//				}

			//test password
			@Test
			public void isInvalidAdminPass() throws Exception {
				ee.expectMessage("Validator.Invalid_Password");
				Admin a =new Admin();
				a.setPassword("12a");
				v.validAdminPassword(a);
			}
			@Test
			public void isValidAdminPass() throws Exception {
				ee.expectMessage("Validator.Valid_Password");
				Admin a =new Admin();
				a.setPassword("12agj3");
				v.validAdminPassword(a);
			}
			

		
		
}
