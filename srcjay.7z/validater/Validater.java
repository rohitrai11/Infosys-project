package validater;

import java.time.LocalDate;

import org.apache.logging.log4j.Logger;

import  com.infy.resources.LogConfig;
import com.infy.model.Admin;
import com.infy.model.Customer;
import com.infy.model.DeliveryBoy;

public class Validater {

	
	// For Customer //
	// for name
	public Void validCustomerName(Customer customer) throws Exception{
		if (customer.getCustomerName().length()==0||customer.getCustomerName().length()==1){
			throw new Exception("Validator.INVALID_Name");
		}
		else
			throw new Exception("Validator.Valid_Name");
		
	}
	
	// for password
	public Void validCustomerPassword(Customer customer) throws Exception{
		if(customer.getPassword().length()<4)
			throw new Exception("Validator.Invalid_Password");
		else
			throw new Exception("Validator.Valid_Password");
	}
	//for phone
	
	public Void validCustomerPhone(Customer customer) throws Exception{
		if(customer.getContactNo().length()<10)
			throw new Exception("Validator.Invalid_Phone");
		else if (customer.getContactNo().length()==10){
			int f=0;
			for(int i=1;i<10;i++){
				if(customer.getContactNo().charAt(0)==customer.getContactNo().charAt(i))
					f++;
			}
			if(f==9){
				throw new Exception("Validator.Invalid_Phone");
			}
			throw new Exception("Validator.Valid_Phone");
	}
		throw new Exception("Validator.Invalid_Phone");
	}
	// for email

	public Boolean validCustomerEmail(Customer customer) throws Exception{
		int f=0;
		for(int i=0;i<customer.getCustomerEmail().length();i++){
			if (customer.getCustomerEmail().charAt(i)=='@')
				f++;
		}
		if (f==1)
			throw new Exception("Validator.Valid_Email");
		throw new Exception("Validator.Invalid_Email");
		
	}	
	// For DeliveryBoy //
	// for name
	public Boolean validDeliveryBoyName(DeliveryBoy delivery) throws Exception{
		if (delivery.getName().length()<2){
			throw new Exception("Validator.INVALID_Name");
		}
		else
			throw new Exception("Validator.Valid_Name");
	}
	
	// for password
	public Boolean validDeliveryBoyPassword(DeliveryBoy delivery) throws Exception{
		if(delivery.getPassword().length()<4)
			throw new Exception("Validator.Invalid_Password");
		else
			throw new Exception("Validator.Valid_Password");	}
	
	//for phone
	
	public Boolean validDeliveryBoyPhone(DeliveryBoy delivery) throws Exception{
		if(delivery.getContactNo().length()<10)
			throw new Exception("Validator.Invalid_Phone");
		else if (delivery.getContactNo().length()==10){
			int f=0;
			for(int i=1;i<10;i++){
				if(delivery.getContactNo().charAt(0)==delivery.getContactNo().charAt(i))
					f++;
			}
			if(f==9){
				throw new Exception("Validator.Invalid_Phone");
			}
			throw new Exception("Validator.Valid_Phone");
	}
		throw new Exception("Validator.Invalid_Phone");
	}
	
	
	// for email

	public Boolean validDeliveryBoyEmail(DeliveryBoy delivery) throws Exception{
		int f=0;
		for(int i=0;i<delivery.getEmail().length();i++){
			if (delivery.getEmail().charAt(i)=='@')
				f++;
		}
		if (f==1)
			throw new Exception("Validator.Valid_Email");
		throw new Exception("Validator.Invalid_Email");
	}
	
	
	// for date of joining //
	
	public Boolean validDeliveryBoyDate(DeliveryBoy delivery){
		LocalDate localDate = LocalDate.now();
		if(delivery.getDateOfJoining().after(localDate)){
			return false;
		}
		return true;
	}

	// for Admin //
	public Void validAdminPassword(Admin admin) throws Exception{
		if(admin.getPassword().length()<4)
			throw new Exception("Validator.Invalid_Password");
		else
			throw new Exception("Validator.Valid_Password");	}

}
